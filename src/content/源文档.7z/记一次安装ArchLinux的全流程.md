# 关于我自己习惯的安装 ArchLinux 的全流程记录
本文采用的是Proxmox VE虚拟机安装形式，硬盘部分通过模拟SSD形态标定硬盘名称。
版本采用ArchLinux 2025.3.1，Archiso的内核版本为6.13.5-arch1-1。

## 1.准备工作
创建好一个虚拟机，流程不再演示，注意安装过程中勾选UEFI和EFI硬盘以便后续安装。勾选使用GUEST AGENT，以监控虚拟机状态和管理。
配置好虚拟机选项后，点击 ▶️Boot 启动虚拟机，出现Proxmox Logo的时候狂点F2进入QEMUKVM的BIOS设置界面

