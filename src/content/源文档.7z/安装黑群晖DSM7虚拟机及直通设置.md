---
title: 安装黑群晖DSM7虚拟机及直通设置
updated: 2024-06-16 06:50:49Z
created: 2024-06-01 10:51:30Z
latitude: 31.29897900
longitude: 120.58529000
altitude: 0.0000
---

# PVE安装黑群晖DSM7虚拟机及直通设置

本篇讲一下如何在pve中安装黑群晖,以及黑群晖的硬盘直通如何设置

## 准备

1.提前下载好黑群晖引导以及镜像(这里我推荐使用[openos论坛大佬分享的引导](https://www.openos.org/threads/2023317dsm7-x7-2-64216.3529/))

2.pve宿主机(搭建可参考我上篇文章 [Pve(Proxmox VE)安装教程](https://blog.mstg.top/?p=730) )

3.至少一个sata盘(注意,群晖系统只支持sata盘符,其他如sas,scsi等都无法识别)

## 安装过程

### 一.创建虚拟机

1.名称随意,VM ID需要记一下,后面要用

[<img fetchpriority="high" decoding="async" width="640" height="449" src="../_resources/pve_dsm7install_0.pngresize6402C449amp" alt="" class="wp-image-773 jop-noMdConv" srcset="https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_0.png?w=732&amp;ssl=1 732w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_0.png?resize=300%2C210&amp;ssl=1 300w" sizes="(max-width: 640px) 100vw, 640px" style="box-sizing: content-box; height: auto; max-width: 100%; border: 0px none; vertical-align: bottom; background-color: #ffffff;">](https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_0.png?ssl=1 "PVE安装黑群晖DSM7虚拟机及直通设置")

2.这里选`不需要任何介质`

[<img decoding="async" width="640" height="467" src="../_resources/pve_dsm7install_1.pngresize6402C467amp" alt="" class="wp-image-774 jop-noMdConv" srcset="https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_1.png?w=730&amp;ssl=1 730w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_1.png?resize=300%2C219&amp;ssl=1 300w" sizes="(max-width: 640px) 100vw, 640px" style="box-sizing: content-box; height: auto; max-width: 100%; border: 0px none; vertical-align: bottom; background-color: #ffffff;">](https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_1.png?ssl=1 "PVE安装黑群晖DSM7虚拟机及直通设置")

3.机型建议改成q35,如果机子太老就保持默认

[<img loading="lazy" decoding="async" width="640" height="452" src="../_resources/pve_dsm7install_2.pngresize6402C452amp" alt="" class="wp-image-775 jop-noMdConv" srcset="https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_2.png?w=827&amp;ssl=1 827w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_2.png?resize=300%2C212&amp;ssl=1 300w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_2.png?resize=768%2C542&amp;ssl=1 768w" sizes="(max-width: 640px) 100vw, 640px" style="box-sizing: content-box; height: auto; max-width: 100%; border: 0px none; vertical-align: bottom; background-color: #ffffff;">](https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_2.png?ssl=1 "PVE安装黑群晖DSM7虚拟机及直通设置")

4.硬盘可以先不设置,或者一会创建完虚拟机后删除

[<img loading="lazy" decoding="async" width="640" height="438" src="../_resources/pve_dsm7install_3.pngresize6402C438amp" alt="" class="wp-image-776 jop-noMdConv" srcset="https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_3.png?w=792&amp;ssl=1 792w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_3.png?resize=300%2C205&amp;ssl=1 300w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_3.png?resize=768%2C526&amp;ssl=1 768w" sizes="(max-width: 640px) 100vw, 640px" data-recalc-dims="1" style="box-sizing: content-box; height: auto; max-width: 100%; border: 0px none; vertical-align: bottom; background-color: #ffffff;">](https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_3.png?ssl=1 "PVE安装黑群晖DSM7虚拟机及直通设置")

5.cpu核心按需分配(注意cpu类别选择`host`类型)

[<img loading="lazy" decoding="async" width="640" height="458" src="../_resources/pve_dsm7install_4.pngresize6402C458amp" alt="" class="wp-image-777 jop-noMdConv" srcset="https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_4.png?w=724&amp;ssl=1 724w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_4.png?resize=300%2C215&amp;ssl=1 300w" sizes="(max-width: 640px) 100vw, 640px" data-recalc-dims="1" style="box-sizing: content-box; height: auto; max-width: 100%; border: 0px none; vertical-align: bottom; background-color: #ffffff;">](https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_4.png?ssl=1 "PVE安装黑群晖DSM7虚拟机及直通设置")

6.内存大小按需设置(个人建议4G,即4096MiB以上)

[<img loading="lazy" decoding="async" width="640" height="451" src="../_resources/pve_dsm7install_5.pngresize6402C451amp" alt="" class="wp-image-781 jop-noMdConv" srcset="https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_5.png?w=906&amp;ssl=1 906w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_5.png?resize=300%2C211&amp;ssl=1 300w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_5.png?resize=768%2C541&amp;ssl=1 768w" sizes="(max-width: 640px) 100vw, 640px" data-recalc-dims="1" style="box-sizing: content-box; height: auto; max-width: 100%; border: 0px none; vertical-align: bottom; background-color: #ffffff;">](https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_5.png?ssl=1 "PVE安装黑群晖DSM7虚拟机及直通设置")

7.网卡模型选择半虚拟化

[<img loading="lazy" decoding="async" width="640" height="458" src="../_resources/pve_dsm7install_6.pngresize6402C458amp" alt="" class="wp-image-782 jop-noMdConv" srcset="https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_6.png?w=756&amp;ssl=1 756w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_6.png?resize=300%2C215&amp;ssl=1 300w" sizes="(max-width: 640px) 100vw, 640px" data-recalc-dims="1" style="box-sizing: content-box; height: auto; max-width: 100%; border: 0px none; vertical-align: bottom; background-color: #ffffff;">](https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_6.png?ssl=1 "PVE安装黑群晖DSM7虚拟机及直通设置")

## 二.转换虚拟磁盘，设置磁盘直通

1.将你需要的机型引导镜像上传到pve中(我这里使用的DS918的引导文件)

PS:这里因为我们装的是虚拟机环境下的群晖,所以不需要像安装物理机上要修改引导中的配置文件了

[<img loading="lazy" decoding="async" width="640" height="370" src="../_resources/pve_dsm7install_7.pngresize6402C370amp" alt="" class="wp-image-783 jop-noMdConv" srcset="https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_7.png?resize=1024%2C592&amp;ssl=1 1024w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_7.png?resize=300%2C173&amp;ssl=1 300w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_7.png?resize=768%2C444&amp;ssl=1 768w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_7.png?resize=1536%2C888&amp;ssl=1 1536w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_7.png?w=1600&amp;ssl=1 1600w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_7.png?w=1280&amp;ssl=1 1280w" sizes="(max-width: 640px) 100vw, 640px" data-recalc-dims="1" style="box-sizing: content-box; height: auto; max-width: 100%; border: 0px none; vertical-align: bottom; background-color: #ffffff;">](https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_7.png?ssl=1 "PVE安装黑群晖DSM7虚拟机及直通设置")

上传完后会有提示保存的位置,复制一下一会要用.

[<img loading="lazy" decoding="async" width="640" height="392" src="../_resources/pve_dsm7install_8.pngresize6402C392amp" alt="" class="wp-image-784 jop-noMdConv" srcset="https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_8.png?resize=1024%2C627&amp;ssl=1 1024w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_8.png?resize=300%2C184&amp;ssl=1 300w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_8.png?resize=768%2C470&amp;ssl=1 768w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_8.png?w=1037&amp;ssl=1 1037w" sizes="(max-width: 640px) 100vw, 640px" data-recalc-dims="1" style="box-sizing: content-box; height: auto; max-width: 100%; border: 0px none; vertical-align: bottom; background-color: #ffffff;">](https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_8.png?ssl=1 "PVE安装黑群晖DSM7虚拟机及直通设置")

2.使用ssh连接到pve宿主机上,使用下面命令将引导镜像转为虚拟磁盘挂载到虚拟机上

```gradle
qm importdisk <VMID> /var/lib/vz/template/iso/ <镜像名称> local
## 删除LVM分区后的位置

```

出现下图这样提示,表示转换完成

[<img loading="lazy" decoding="async" width="640" height="406" src="../_resources/pve_dsm7install_9.pngresize6402C406amp" alt="" class="wp-image-785 jop-noMdConv" srcset="https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_9.png?w=772&amp;ssl=1 772w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_9.png?resize=300%2C190&amp;ssl=1 300w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_9.png?resize=768%2C487&amp;ssl=1 768w" sizes="(max-width: 640px) 100vw, 640px" data-recalc-dims="1" style="box-sizing: content-box; height: auto; max-width: 100%; border: 0px none; vertical-align: bottom; background-color: #ffffff;">](https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_9.png?ssl=1 "PVE安装黑群晖DSM7虚拟机及直通设置")

3.在对应虚拟机的硬件一栏中就会发现有个`未使用的磁盘`

[<img loading="lazy" decoding="async" width="640" height="271" src="../_resources/pve_dsm7install_10.pngresize6402C271amp" alt="" class="wp-image-786 jop-noMdConv" srcset="https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_10.png?resize=1024%2C433&amp;ssl=1 1024w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_10.png?resize=300%2C127&amp;ssl=1 300w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_10.png?resize=768%2C325&amp;ssl=1 768w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_10.png?resize=1536%2C649&amp;ssl=1 1536w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_10.png?w=1602&amp;ssl=1 1602w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_10.png?w=1280&amp;ssl=1 1280w" sizes="(max-width: 640px) 100vw, 640px" data-recalc-dims="1" style="box-sizing: content-box; height: auto; max-width: 100%; border: 0px none; vertical-align: bottom; background-color: #ffffff;">](https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_10.png?ssl=1 "PVE安装黑群晖DSM7虚拟机及直通设置")

点击上方编辑,将该虚拟磁盘设置为sata硬盘

[<img loading="lazy" decoding="async" width="640" height="239" src="../_resources/pve_dsm7install_11.pngresize6402C239amp" alt="" class="wp-image-787 jop-noMdConv" srcset="https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_11.png?w=861&amp;ssl=1 861w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_11.png?resize=300%2C112&amp;ssl=1 300w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_11.png?resize=768%2C287&amp;ssl=1 768w" sizes="(max-width: 640px) 100vw, 640px" data-recalc-dims="1" style="box-sizing: content-box; height: auto; max-width: 100%; border: 0px none; vertical-align: bottom; background-color: #ffffff;">](https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_11.png?ssl=1 "PVE安装黑群晖DSM7虚拟机及直通设置")

4.此外添加一个sata盘,用于安装群晖套件及数据

注意,我这里选择的是直接直通sata控制器,让虚拟机获取我sata盘的管理权限

(如果仿照我操作,**请确保pve系统盘不在该控制器管理下**,否则系统将崩溃!!!!!!!!!! 切记!)

[<img loading="lazy" decoding="async" width="640" height="278" src="../_resources/pve_dsm7install_12.pngresize6402C278amp" alt="" class="wp-image-788 jop-noMdConv" srcset="https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_12.png?resize=1024%2C444&amp;ssl=1 1024w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_12.png?resize=300%2C130&amp;ssl=1 300w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_12.png?resize=768%2C333&amp;ssl=1 768w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_12.png?w=1217&amp;ssl=1 1217w" sizes="(max-width: 640px) 100vw, 640px" data-recalc-dims="1" style="box-sizing: content-box; height: auto; max-width: 100%; border: 0px none; vertical-align: bottom; background-color: #ffffff;">](https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_12.png?ssl=1 "PVE安装黑群晖DSM7虚拟机及直通设置")

这里可以看到ID为0000:00.17.0的设备名是sata controller(sata控制器),将这个设备直通给群晖,方便群晖读取硬盘信息及控制硬盘启停.

同时注意将高级选项中的PCIE选项勾选

[<img loading="lazy" decoding="async" width="640" height="284" src="../_resources/pve_dsm7install_13.pngresize6402C284amp" alt="" class="wp-image-789 jop-noMdConv" srcset="https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_13.png?w=783&amp;ssl=1 783w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_13.png?resize=300%2C133&amp;ssl=1 300w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_13.png?resize=768%2C340&amp;ssl=1 768w" sizes="(max-width: 640px) 100vw, 640px" data-recalc-dims="1" style="box-sizing: content-box; height: auto; max-width: 100%; border: 0px none; vertical-align: bottom; background-color: #ffffff;">](https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_13.png?ssl=1 "PVE安装黑群晖DSM7虚拟机及直通设置")

5.在虚拟机的设备一栏中,选择设置引导顺序

[<img loading="lazy" decoding="async" width="640" height="282" src="../_resources/pve_dsm7install_14.pngresize6402C282amp" alt="" class="wp-image-790 jop-noMdConv" srcset="https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_14.png?resize=1024%2C451&amp;ssl=1 1024w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_14.png?resize=300%2C132&amp;ssl=1 300w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_14.png?resize=768%2C338&amp;ssl=1 768w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_14.png?resize=1536%2C676&amp;ssl=1 1536w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_14.png?w=1602&amp;ssl=1 1602w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_14.png?w=1280&amp;ssl=1 1280w" sizes="(max-width: 640px) 100vw, 640px" data-recalc-dims="1" style="box-sizing: content-box; height: auto; max-width: 100%; border: 0px none; vertical-align: bottom; background-color: #ffffff;">](https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_14.png?ssl=1 "PVE安装黑群晖DSM7虚拟机及直通设置")

将引导镜像的虚拟磁盘勾选,其他不勾选

[<img loading="lazy" decoding="async" width="640" height="253" src="../_resources/pve_dsm7install_15.pngresize6402C253amp" alt="" class="wp-image-791 jop-noMdConv" srcset="https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_15.png?w=943&amp;ssl=1 943w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_15.png?resize=300%2C119&amp;ssl=1 300w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_15.png?resize=768%2C304&amp;ssl=1 768w" sizes="(max-width: 640px) 100vw, 640px" data-recalc-dims="1" style="box-sizing: content-box; height: auto; max-width: 100%; border: 0px none; vertical-align: bottom; background-color: #ffffff;">](https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_15.png?ssl=1 "PVE安装黑群晖DSM7虚拟机及直通设置")

6.开启虚拟机后等几分钟,大概有这个提示之后就能访问群晖控制面板了

[<img loading="lazy" decoding="async" width="640" height="365" src="../_resources/pve_dsm7install_16.pngresize6402C365amp" alt="" class="wp-image-792 jop-noMdConv" srcset="https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_16.png?w=1017&amp;ssl=1 1017w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_16.png?resize=300%2C171&amp;ssl=1 300w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_16.png?resize=768%2C438&amp;ssl=1 768w" sizes="(max-width: 640px) 100vw, 640px" data-recalc-dims="1" style="box-sizing: content-box; height: auto; max-width: 100%; border: 0px none; vertical-align: bottom; background-color: #ffffff;">](https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_16.png?ssl=1 "PVE安装黑群晖DSM7虚拟机及直通设置")

7.在你的路由器上找到新出现的设备(设备名一般是`DiskStation`),查看该设备ip,群晖的默认访问地址是 `http://你的虚拟机ip:5000`

[<img loading="lazy" decoding="async" width="640" height="376" src="../_resources/pve_dsm7install_17.pngresize6402C376amp" alt="" class="wp-image-793 jop-noMdConv" srcset="https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_17.png?resize=1024%2C602&amp;ssl=1 1024w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_17.png?resize=300%2C176&amp;ssl=1 300w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_17.png?resize=768%2C452&amp;ssl=1 768w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_17.png?w=1124&amp;ssl=1 1124w" sizes="(max-width: 640px) 100vw, 640px" data-recalc-dims="1" style="box-sizing: content-box; height: auto; max-width: 100%; border: 0px none; vertical-align: bottom; background-color: #ffffff;">](https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_17.png?ssl=1 "PVE安装黑群晖DSM7虚拟机及直通设置")

8.上传系统安装包

[<img loading="lazy" decoding="async" width="581" height="621" src="../_resources/pve_dsm7install_18.pngresize5812C621amp" alt="" class="wp-image-794 jop-noMdConv" srcset="https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_18.png?w=581&amp;ssl=1 581w, https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_18.png?resize=281%2C300&amp;ssl=1 281w" sizes="(max-width: 581px) 100vw, 581px" data-recalc-dims="1" style="box-sizing: content-box; height: auto; max-width: 100%; border: 0px none; vertical-align: bottom; background-color: #ffffff;">](https://i0.wp.com/blog.mstg.top/wp-content/uploads/pve_dsm7install_18.png?ssl=1 "PVE安装黑群晖DSM7虚拟机及直通设置")

9\. 然后就可以进行注册等操作了

PS:记得更新选项里面选`手动升级`

并跳过注册群辉

**大功告成**