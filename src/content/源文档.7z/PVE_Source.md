# PVE_Source

#小软件

## 该脚本为 Proxmox VE 用户提供便捷的管理和配置工具，包括系统更新、UI美化、高级配置及CPU优化等，极大简化系统维护和个性化设置流程。

### 2024-1-6🌸开发版本 

相较于前版本更新显卡直通流程

```bash
wget -q -O /root/pve_source.tar.gz 'https://bbs.x86pi.cn/file/topic/2024-01-06/file/24f723efc6ab4913b1f99c97a1d1a472b2.gz' && tar zxvf /root/pve_source.tar.gz && /root/./pve_source
```

### 2023-11-28🌸正式版本

兼容性较好版本

```bash
 wget -q -O /root/pve_source.tar.gz 'https://bbs.x86pi.cn/file/topic/2023-11-28/file/01ac88d7d2b840cb88c15cb5e19d4305b2.gz' && tar zxvf /root/pve_source.tar.gz && /root/./pve_source
```

