# 一站式PVE,truenas,win,docker开荒（踩坑）指南



## 前言

上期主要跟大家介绍了我的ALL In One NAS家庭服务器搭建硬件篇，大家十分热情，我也从评论区中学到了很多。相信大家都想明白一个问题，ALL In One NAS究竟能做些什么？本期来跟大家介绍一下软件篇，分享一下我的踩坑心得。 如果你还没有进行部署，刚好可以看这期视频，有一个方向，如果已经部署过了，也可以查缺补漏。前排提示，本期内容全程干货，可能有些地方比较晦涩难懂，UP也会以通俗易懂的语言解释，在简介区也有本期视频的文字版，所有出现的链接，代码，参考文献都会放到简介评论区中，大家有需要自取。希望大家能一键三连，那我们现在开始。

## Ventoy无法安装PVE？

大家可能以为，踩坑指南要从PVE安装完毕后开始，没想到步子还没迈开就被绊了一跤。 安装PVE镜像时，我们有很多工具可以选择，比如rufus，Balena Etcher（BE），不过我还是喜欢使用Ventoy，只需要把PVE镜像放入u盘根目录，开机时选择即可。不过在我安装PVE8.1时老是报报错,找不到镜像。

`no device with valid ISO found, please check your installation medium unable to continue (type exit or CTRL-D to reboot)  ` 我以为是镜像出错了，又下载一遍发现还是如此。最后在GitHub中查询发现大家都有这种问题，后来Ventoy发布了新版本解决了这个bug。如果现在大家想用Ventoy安装pve的话记得先升级哦

参考链接： [问题来源](https://github.com/ventoy/Ventoy/issues/2657)

![notion image](https://www.notion.so/image/https%3A%2F%2Fprod-files-secure.s3.us-west-2.amazonaws.com%2F69b25f4d-4a93-4f64-851e-8661f2dccf10%2F2c43ea2c-ca3c-4cf1-ad1b-c013e49e9117%2F285530296-4ea33949-e85a-4421-a5ca-d0b7339a414f.jpg?table=block&id=1632bed4-e739-8061-a580-e8ab61129ba7&t=1632bed4-e739-8061-a580-e8ab61129ba7&width=1217.1875&cache=v2)

系统安装完毕后屏幕上会显示登录IP，我们在浏览器中输入，就到了最基础的PVE设置

## PVE基础设置

我们要做的有换源，禁用企业源，更改CPU调度模式，频率温度面板显示等等。 这里我推荐大家使用pvetools进行部署，点击节点，Shell，将这串代码粘贴到命令行中回车即可。

### plain



```plain
echo "nameserver  8.8.8.8" >> /etc/resolv.conf && rm -rf pvetools && rm -rf /etc/apt/sources.list.d/pve-enterprise.list && export LC_ALL=en_US.UTF-8 && apt update && apt -y install git && git clone <https://github.com/ivanhao/pvetools.git> && echo "cd /root/pvetools && ./pvetools.sh" > pvetools/pvetools && chmod +x pvetools/pvetools* && ln -s /root/pvetools/pvetools /usr/local/bin/pvetools && pvetools
```

在这里我建议大家进行换源，安装配置CPU省电，开启直通支持，安装配置温度、CPU频率显示，去除订阅提示。 [GitHub - ivanhao/pvetools: proxmox ve tools script(debian9+ can use it).Including email, samba, NFS set zfs max ram, nested virtualization ,docker , pci passthrough etc. for english user,please look the end of readme.](https://github.com/ivanhao/pvetools)

![notion image](https://www.notion.so/image/https%3A%2F%2Fprod-files-secure.s3.us-west-2.amazonaws.com%2F69b25f4d-4a93-4f64-851e-8661f2dccf10%2Fbd18cf50-68cf-44b6-9627-56751dc07bc6%2FPasted_image_20240323170833.png?table=block&id=1632bed4-e739-806b-b386-f0bce909e5c4&t=1632bed4-e739-806b-b386-f0bce909e5c4&width=1217.175048828125&cache=v2)

## GVT-G核显拆分

> [!NOTE] 前排提醒：如果你想用核显进行显示器输出，请用直通，不要拆分。

如果跟我一样既想在Docker里面使用核显硬解视频，又想在Windows里用核显硬件加速或者还想在DSM中实现视频解码，人脸识别。那么不妨试试核显虚拟化，把一个核显拆成多个来用。

> 下面的方法适用于intel10代及以下CPU，11代以上可以使用SR-IOV核显虚拟化，这样效率更高

大家在进行核显拆分之前记得给核显足够的显存，我给了512MB，要不然拆分不了核显。 接着就是运行下面命令进行GRUB配置，添加内核模块，进行核显拆分。

![notion image](https://www.notion.so/image/https%3A%2F%2Fprod-files-secure.s3.us-west-2.amazonaws.com%2F69b25f4d-4a93-4f64-851e-8661f2dccf10%2F269f188f-d88d-4031-a1b4-108ea5665199%2FPasted_image_20240323171054.png?table=block&id=1632bed4-e739-80f8-b21c-db7c0e46c5ab&t=1632bed4-e739-80f8-b21c-db7c0e46c5ab&width=1217.1875&cache=v2)

[硬件虚拟化 显卡直通与GVT-g教程](https://post.smzdm.com/p/all5nm7e/)[PVE8.1+核显gvt-g+黑群晖教程](https://blog.csdn.net/m0_63529939/article/details/136353982)[同时独显直通和核显虚拟化](https://zhuanlan.zhihu.com/p/571224296)

成功后，后续创建虚拟机时，我们可以在【硬件】-->【添加】-->【PCI设备】原始设备中，选择我们的显卡，在mdev类型中选择你想用的显存及分辨率即可。

![notion image](https://www.notion.so/image/https%3A%2F%2Fprod-files-secure.s3.us-west-2.amazonaws.com%2F69b25f4d-4a93-4f64-851e-8661f2dccf10%2F2dab9307-4850-4f5d-b548-9d64b3b223d6%2FPasted_image_20240323171851.png?table=block&id=1632bed4-e739-8097-b155-ea073805966f&t=1632bed4-e739-8097-b155-ea073805966f&width=2560&cache=v2)

## 独显VGPU

> [!NOTE] 前排提醒：如果你想用独显进行显示器输出，请用直通，不要拆分。

如果你的CPU没有核显，只用一张显卡做到（在linux系统下）影音服务器硬解+Windows云游戏双用。可以使用VGPU，把独显拆分成多个显卡。 可能有同学会问，我好像听说只有Tesla卡才能拆分，GeForce或Quadro卡没这个功能啊。 的确，只有Tesla卡才能做VGPU。但是也有大神开发出了vGPU Unlock，在家用卡上也能做VGPU。

[NVIDIA vGPU Guide](https://gitlab.com/polloloco/vgpu-proxmox)

当然也是有条件的，你的卡必须是Maxwell 2.0，Pascal，Turing架构，也就是我们常说的，9系，10系，16系，20系，30系之后就不支持了。

由于下面操作比较复杂，再加之粉丝们的要求，所以跟大家实机演示一下，出一期自己的教程。

![notion image](https://www.notion.so/image/https%3A%2F%2Fprod-files-secure.s3.us-west-2.amazonaws.com%2F69b25f4d-4a93-4f64-851e-8661f2dccf10%2Ff683a8b4-9f85-4100-bf64-4177f3ebc811%2FPasted_image_20240323172038.png?table=block&id=1632bed4-e739-8023-bb5e-d208492f08e9&t=1632bed4-e739-8023-bb5e-d208492f08e9&width=1217.1875&cache=v2)

由于我之前装过vGPU驱动了，所以我先停用使用vGPU的虚拟机，再在PVE主机中卸载驱动。 下面正式开始

If you are upgrading from a previous version of this guide, you should uninstall the old driver by running `nvidia-uninstall` first.

### P4 VGPU UNLOCK教程

首先我们先更新并安装相关依赖 将软件包克隆到本地 接着安装rust编译器 进行rsproxy代理 添加path 进行编译 再为 vgpu 解锁配置创建文件夹并创建一个空配置文件 然后，为systemd创建文件夹和文件，以便在启动vgpu服务时加载vgpu_unlock-rs库 如果你的显卡支持VGPU需要运行下面代码禁用配置

#### 固定内核版本

To pin the package to that version, create a file in `/etc/apt/preferences.d/proxmox-default-kernel` with the following content. This will keep `proxmox-default-kernel` on the old version until that file is deleted, and a new upgrade is initiated:

Package: proxmox-default-kernel Pin: version 1.0.1 Pin-Priority: 1000

#### 更新并安装依赖

### plain



```plain
apt update
apt dist-upgrade
```

Plain text

Copy

安装更多的软件包，如 git、编译器和其他一些工具

### plain



```plain
apt install -y git build-essential dkms pve-headers mdevctl
```

Plain text

Copy

将两个存储库克隆到本地 首先，将此存储库克隆到您的主文件夹（在本例中`/root/`）

### plain



```plain
git clone <https://gitlab.com/polloloco/vgpu-proxmox.git>
```

Plain text

Copy

您还需要 vgpu_unlock-rs 存储库

### plain



```plain
cd /opt
git clone <https://github.com/polloloco/vgpu_unlock-rs.git>
```

Plain text

Copy

之后，安装rust编译器 国内拉取 [crates.io](http://crates.io/) 以及安装 Rust 会面临流量出境不稳定的问题这里，使用rsproxy代理

编辑bashrc

### plain



```plain
nano ~/.bashrc
```

Plain text

Copy

在底部添加下面两行文字

### plain



```plain
export RUSTUP_DIST_SERVER="<https://rsproxy.cn>"
export RUSTUP_UPDATE_ROOT="<https://rsproxy.cn/rustup>"
```

Plain text

Copy

`Ctrl + X`，然后按 `Y` 确认保存，最后按 `Enter`退出

### plain



```plain
source ~/.bashrc
```

Plain text

Copy

刷新bashrc

### plain



```plain
curl <https://sh.rustup.rs> -sSf | sh -s -- -y --profile minimal
```

Plain text

Copy

步骤二：安装 Rust（请先完成步骤一的环境变量导入并 source rc 文件或重启终端生效）

### shell



```shell
curl --proto '=https' --tlsv1.2 -sSf <https://rsproxy.cn/rustup-init.sh> | sh
```

Shell

Copy

步骤三：设置 [crates.io](http://crates.io/) 镜像， 修改配置 nano ~/.cargo/config，已支持git协议和sparse协议，>=1.68 版本建议使用 sparse-index，速度更快。

### shell



```shell
[source.crates-io]
replace-with = 'rsproxy-sparse'
[source.rsproxy]
registry = "<https://rsproxy.cn/crates.io-index>"
[source.rsproxy-sparse]
registry = "sparse+https://rsproxy.cn/index/"
[registries.rsproxy]
index = "<https://rsproxy.cn/crates.io-index>"
[net]
git-fetch-with-cli = true
```

Shell

Copy

添加path 现在使 rust 二进制文件在您的 $PATH 中可用（您只需在安装 rust 后第一次执行此操作）

### plain



```plain
source $HOME/.cargo/env
```

Plain text

Copy

进入`vgpu_unlock-rs`目录并编译库。根据您的硬件和互联网连接，可能需要一段时间

### plain



```plain
cd vgpu_unlock-rs/
cargo build --release
```

Plain text

Copy

vgpu_unlock-rs 库需要一些文件和文件夹才能正常工作，让我们创建这些文件和文件夹 首先为 vgpu 解锁配置创建文件夹并创建一个空配置文件

### plain



```plain
mkdir /etc/vgpu_unlock
touch /etc/vgpu_unlock/profile_override.toml
```

Plain text

Copy

然后，为systemd创建文件夹和文件，以便在启动nvidia vgpu服务时加载vgpu_unlock-rs库

### plain



```plain
mkdir /etc/systemd/system/{nvidia-vgpud.service.d,nvidia-vgpu-mgr.service.d}
echo -e "[Service]\\nEnvironment=LD_PRELOAD=/opt/vgpu_unlock-rs/target/release/libvgpu_unlock_rs.so" > /etc/systemd/system/nvidia-vgpud.service.d/vgpu_unlock.conf
echo -e "[Service]\\nEnvironment=LD_PRELOAD=/opt/vgpu_unlock-rs/target/release/libvgpu_unlock_rs.so" > /etc/systemd/system/nvidia-vgpu-mgr.service.d/vgpu_unlock.conf
```

Plain text

Copy

如果你的显卡支持VGPU需要运行下面代码：

### plain



```plain
echo "unlock = false" > /etc/vgpu_unlock/config.toml
```

Plain text

Copy

如果你的显卡不支持，或按照流程阅读完毕后仍然无法启动，需要阅读下面教程开启IOMMU https://gitlab.com/polloloco/vgpu-proxmox#enabling-iommu

配置内核：

### plain



```plain
echo vfio >> /etc/modules
echo vfio_iommu_type1 >> /etc/modules
echo vfio_pci >> /etc/modules
echo vfio_virqfd >> /etc/modules
echo  "blacklist nouveau" >> /etc/modprobe.d/blacklist.conf
echo "options kvm ignore_msrs=1" > /etc/modprobe.d/kvm.conf
update-initramfs -k all -u
```

Plain text

Copy

开启iommu

### plain



```plain
#编辑grub，根据自己的环境，选择设置
nano /etc/default/grub
#在里面找到：
GRUB_CMDLINE_LINUX_DEFAULT="quiet"
#然后修改为：
GRUB_CMDLINE_LINUX_DEFAULT="quiet intel_iommu=on"
#更新引导
update-grub
```

Plain text

Copy

#### 获取驱动

由于通过英伟达官方流程获取VGPU驱动十分繁杂，大家可以从佛西大佬的博客获取VGPU驱动，下载zip包即可。 https://foxi.buduanwang.vip/pan/vGPU/

我的显卡是TESLA P4，从这个表里看，我只能用16驱动，最新的17驱动用不了，我选择了最新的16.4驱动 [驱动下载链接](https://foxi.buduanwang.vip/pan/vGPU/16.4/)[# NVIDIA® Virtual GPU Software Supported GPUs](https://docs.nvidia.com/grid/gpus-supported-by-vgpu.html)

![notion image](https://www.notion.so/image/https%3A%2F%2Fprod-files-secure.s3.us-west-2.amazonaws.com%2F69b25f4d-4a93-4f64-851e-8661f2dccf10%2F0c692785-f085-4d91-8bfd-023ee75a4870%2FPasted_image_20240323172306.png?table=block&id=1632bed4-e739-8001-829c-de38eaab0a7d&t=1632bed4-e739-8001-829c-de38eaab0a7d&width=1217.1875&cache=v2)

#### 修补驱动

将驱动包下载完成后，我们需要把包传给PVE，在本地电脑或PVE上解压都行

![notion image](https://www.notion.so/image/https%3A%2F%2Fprod-files-secure.s3.us-west-2.amazonaws.com%2F69b25f4d-4a93-4f64-851e-8661f2dccf10%2Ffde5c547-1ff0-4d8a-b13c-78552515502a%2FEDE9394D-9C97-4902-8A64-C9AA88E637FC.png?table=block&id=1632bed4-e739-8009-bd0d-d4e9a375392d&t=1632bed4-e739-8009-bd0d-d4e9a375392d&width=1217.175048828125&cache=v2)

打开host driver，我们可以看到一个run文件 先给该文件赋权

### plain



```plain
chmod +x NVIDIA-Linux-x86_64-535.161.05-vgpu-kvm.run
```

Plain text

Copy

### plain



```plain
apt update && apt install pve-headers-$(uname -r)
```

Plain text

Copy

之后修补该驱动，照理说我们P4用驱动应该不用修补，但后面发现不修补安装不了，所以我们还是修补一下。

出现下面一段文字表示成功 现在应该有一个名为custom.run的文件这就是修补后的驱动

![notion image](https://www.notion.so/image/https%3A%2F%2Fprod-files-secure.s3.us-west-2.amazonaws.com%2F69b25f4d-4a93-4f64-851e-8661f2dccf10%2F1673c173-f99e-4ae4-9d8c-88bf08966356%2FPasted_image_20240323173625.png?table=block&id=1632bed4-e739-80b7-95ec-f1fac066ac0c&t=1632bed4-e739-80b7-95ec-f1fac066ac0c&width=1217.1500244140625&cache=v2)

直接安装即可 安装程序会问你 我们回答yes 如果一切顺利，你将看到这条消息 单击`Ok`退出安装程序 输入reboot重启PVE 等待服务器重新启动，然后在 shell 中输入以下内容以检查驱动程序安装是否有效 如果出现下框表示成功 要验证 vGPU 解锁是否有效，可以输入以下命令 出现这条表示成功。

### plain



```plain
./NVIDIA-Linux-x86_64-550.54.10-vgpu-kvm.run --apply-patch ~/vgpu-proxmox/550.54.10.patch
```

Plain text

Copy

出现表示成功： `Self-extractible archive "NVIDIA-Linux-x86_64-550.54.10-vgpu-kvm-custom.run" successfully created. ` 您现在应该有一个名为 的文件`NVIDIA-Linux-x86_64-550.54.10-vgpu-kvm-custom.run`，这是您修补的驱动程序。

现在已应用所需的补丁，您可以安装驱动程序

### plain



```plain
./NVIDIA-Linux-x86_64-550.54.10-vgpu-kvm-custom.run --dkms -m=kernel
```

Plain text

Copy

安装程序会询问您`Would you like to register the kernel module sources with DKMS? This will allow DKMS to automatically build a new module, if you install a different kernel later.`，回答为`Yes`。

如果一切顺利，您将看到此消息。

```
Installation of the NVIDIA Accelerated Graphics Driver for Linux-x86_64 (version: 550.54.10) is now complete.
```

单击`Ok`退出安装程序。

要完成安装，请重新启动。

### plain



```plain
reboot
```

Plain text

Copy

#### 收尾工作

等待服务器重新启动，然后在 shell 中输入以下内容以检查驱动程序安装是否有效

### plain



```plain
nvidia-smi
```

Plain text

Copy

您应该得到与此类似的输出

### plain



```plain
Tue Jan 24 20:21:28 2023
+-----------------------------------------------------------------------------+
| NVIDIA-SMI 525.85.07    Driver Version: 525.85.07    CUDA Version: N/A      |
|-------------------------------+----------------------+----------------------+
| GPU  Name        Persistence-M| Bus-Id        Disp.A | Volatile Uncorr. ECC |
| Fan  Temp  Perf  Pwr:Usage/Cap|         Memory-Usage | GPU-Util  Compute M. |
|                               |                      |               MIG M. |
|===============================+======================+======================|
|   0  NVIDIA GeForce ...  On   | 00000000:01:00.0 Off |                  N/A |
| 26%   33C    P8    43W / 260W |     85MiB / 11264MiB |      0%      Default |
|                               |                      |                  N/A |
+-------------------------------+----------------------+----------------------+

+-----------------------------------------------------------------------------+
| Processes:                                                                  |
|  GPU   GI   CI        PID   Type   Process name                  GPU Memory |
|        ID   ID                                                   Usage      |
|=============================================================================|
|  No running processes found                                                 |
+-----------------------------------------------------------------------------+
```

Plain text

Copy

要验证 vGPU 解锁是否有效，请输入以下命令

SRIOV https://pve.proxmox.com/mediawiki/index.php?title=NVIDIA_vGPU_on_Proxmox_VE_7.x&oldid=11652#Enabling_SR-IOV

0000:00:10.0

### plain



```plain
mdevctl types
```

Plain text

Copy

输出将与此类似

### plain



```plain
0000:01:00.0
  nvidia-256
    Available instances: 24
    Device API: vfio-pci
    Name: GRID RTX6000-1Q
    Description: num_heads=4, frl_config=60, framebuffer=1024M, max_resolution=5120x2880, max_instance=24
  nvidia-257
    Available instances: 12
    Device API: vfio-pci
    Name: GRID RTX6000-2Q
    Description: num_heads=4, frl_config=60, framebuffer=2048M, max_resolution=7680x4320, max_instance=12
  nvidia-258
    Available instances: 8
    Device API: vfio-pci
    Name: GRID RTX6000-3Q
    Description: num_heads=4, frl_config=60, framebuffer=3072M, max_resolution=7680x4320, max_instance=8
---SNIP---
```

Plain text

Copy

如果此命令不返回任何输出，则 vGPU 解锁不起作用。

您可以尝试查看您的卡是否被识别为启用 vgpu 的另一个命令是：

### plain



```plain
nvidia-smi vgpu
```

Plain text

Copy

如果解锁一切正常，输出应类似于以下内容：

### plain



```plain
Tue Jan 24 20:21:43 2023
+-----------------------------------------------------------------------------+
| NVIDIA-SMI 525.85.07              Driver Version: 525.85.07                 |
|---------------------------------+------------------------------+------------+
| GPU  Name                       | Bus-Id                       | GPU-Util   |
|      vGPU ID     Name           | VM ID     VM Name            | vGPU-Util  |
|=================================+==============================+============|
|   0  NVIDIA GeForce RTX 208...  | 00000000:01:00.0             |   0%       |
+---------------------------------+------------------------------+------------+
```

Plain text

Copy

但是，如果您得到此输出，则说明出现问题

### plain



```plain
No supported devices in vGPU mode
```

Plain text

Copy

如果其中任何命令给出错误的输出，您将无法继续。请务必仔细阅读此处的所有内容。

#### 关闭ECC

对于内存，我们需要ECC纠错来保证数据安全，但这张显卡主要是拿来硬解影音和打游戏，开ecc就没必要了，输入下面代码关闭ecc，会释放占用的500mb内存 `nvidia-smi -e 0` 到这里vGPU拆分就完成了。

![notion image](https://www.notion.so/image/https%3A%2F%2Fprod-files-secure.s3.us-west-2.amazonaws.com%2F69b25f4d-4a93-4f64-851e-8661f2dccf10%2F95e9089b-3f1b-4244-b5c8-dd5f6ad60b7f%2FPasted_image_20240323180501.png?table=block&id=1632bed4-e739-8033-b4fd-f6c69567df9d&t=1632bed4-e739-8033-b4fd-f6c69567df9d&width=674&cache=v2)

#### 针对性优化（请安装完Windows系统后再来看）

在使用vgpu有几个限制，比如虚拟显示器分辨率固定，帧数固定在60针，要修改也是非常简单。 我们使用nano修改这个文件

### plain



```plain
nano /etc/vgpu_unlock/profile_override.toml
```

Plain text

Copy

### plain



```plain
[profile.nvidia-65] # choose the profile you want here
num_displays = 1
display_width = 1920
display_height = 1080
max_pixels = 2073600

[vm.100]
frl_enabled = 0
```

Plain text

Copy

这里的[profile.nvidia-65]，根据自己选择的显卡编号修改。我就修改为65 显示器长宽（display_width，display_height）根据自身显示器修改，由于我的显示器是2K屏，所以我把它修改为2560x1440 max_pixels用计算器简单相乘，得出结果应是3686400像素

以上是全局设置，下面的部分表示为单个虚拟机设置

[vm.100]表示你需要应用的虚拟机 frl_enabled = 0表示关闭frl，这样就没有60帧帧数限制了。

#### VGPU授权（请安装完授权容器后再来看）

对于vgpu，nvidia是需要授权的，不过也有大佬制作了获得授权的方法，可以用lxc容器开docker进行容器部署，获得许可证并放在指定位置即可正常使用。

一键安装docker： `bash <(curl -sSL <https://linuxmirrors.cn/docker.sh>)`

[https://docker.lmirror.top](https://docker.lmirror.top/)

## [docker-compose离线安装](https://www.cnblogs.com/jun-zhou/p/18128438)

**1. 下载离线安装文件**

登陆 https://github.com/docker/compose/releases/tag/1.26.2

选择的是1.26.2 的 docker-compose-Linux-x86_64

**2. 把docker-compose-Linux-x86_64复制到/usr/local/bin/并重命名docker-compose，**

mv docker-compose-Linux-x86_64  /usr/local/bin/docker-compose

**3.为二进制文件添加执行权限**

chmod +x /usr/local/bin/docker-compose

**4. 验证安装**

docker-compose --version

### plain



```plain
WORKING_DIR=/opt/docker/fastapi-dls/cert
mkdir -p $WORKING_DIR
cd $WORKING_DIR
# create instance private and public key for singing JWT's
openssl genrsa -out $WORKING_DIR/instance.private.pem 2048
openssl rsa -in $WORKING_DIR/instance.private.pem -outform PEM -pubout -out $WORKING_DIR/instance.public.pem
# create ssl certificate for integrated webserver (uvicorn) - because clients rely on ssl
openssl req -x509 -nodes -days 3650 -newkey rsa:2048 -keyout  $WORKING_DIR/webserver.key -out $WORKING_DIR/webserver.crt
```

Plain text

Copy

### plain



```plain
docker volume create dls-db
docker run -e DLS_URL=`hostname -i` -e DLS_PORT=443 -p 443:443 -v $WORKING_DIR:/app/cert -v dls-db:/app/database collinwebdesigns/fastapi-dls:latest
```

Plain text

Copy

#### 在Linux中获取证书

下载_客户端令牌_并将其放入`/etc/nvidia/ClientConfigToken`：

### plain



```plain
curl --insecure -L -X GET https://<dls-hostname-or-ip>/-/client-token -o /etc/nvidia/ClientConfigToken/client_configuration_token_$(date '+%d-%m-%Y-%H-%M-%S').tok
# or
wget --no-check-certificate -O /etc/nvidia/ClientConfigToken/client_configuration_token_$(date '+%d-%m-%Y-%H-%M-%S').tok https://<dls-hostname-or-ip>/-/client-token
```

Plain text

Copy

重启`nvidia-gridd`服务：

### plain



```plain
service nvidia-gridd restart
```

Plain text

Copy

重启ubuntu虚拟机

### plain



```plain
reboot
```

Plain text

Copy

检查许可状态：

### plain



```plain
nvidia-smi -q | grep "License"
```

Plain text

Copy

输出应该类似于：

### plain



```plain
vGPU Software Licensed Product
    License Status                    : Licensed (Expiry: YYYY-M-DD hh:mm:ss GMT)
```

Plain text

Copy

完毕。有关详细信息，请查看[故障排除部分](https://www.notion.so/limbuntu/68a203b2e39e48de982bc1501b3536e6?v=f1d663faa711447b91f24776cd8db92f&p=5bcf3569436d400e96f562d64de46b73&pm=s#troubleshoot)。

#### 在Windows中获取证书：

**Power-Shell**（以管理员身份运行！）

下载_客户端令牌_并将其放入`C:\\Program Files\\NVIDIA Corporation\\vGPU Licensing\\ClientConfigToken`：

### plain



```plain
curl.exe --insecure -L -X GET https://<dls-hostname-or-ip>/-/client-token -o "C:\\Program Files\\NVIDIA Corporation\\vGPU Licensing\\ClientConfigToken\\client_configuration_token_$($(Get-Date).tostring('dd-MM-yy-hh-mm-ss')).tok"
```

Plain text

Copy

重启`NvContainerLocalSystem`服务：

### plain



```plain
Restart-Service NVDisplay.ContainerLocalSystem
```

Plain text

Copy

检查许可状态：

### plain



```plain
& 'nvidia-smi' -q  | Select-String "License"
```

Plain text

Copy

输出应该类似于：

### plain



```plain
vGPU Software Licensed Product
    License Status                    : Licensed (Expiry: YYYY-M-DD hh:mm:ss GMT)
```

Plain text

Copy

完毕。有关详细信息，请查看[故障排除部分](https://www.notion.so/limbuntu/68a203b2e39e48de982bc1501b3536e6?v=f1d663faa711447b91f24776cd8db92f&p=5bcf3569436d400e96f562d64de46b73&pm=s#troubleshoot)。

https://gitlab.com/polloloco/vgpu-proxmox 关闭ECC https://pve-doc-cn.readthedocs.io/zh-cn/pve-nvidia-vgpu/instdri.htmlhttps://docs.nvidia.com/grid/latest/grid-software-quick-start-guide/index.html#disabling-enabling-ecc-memory

获取许可证 https://git.collinwebdesigns.de/oscar.krause/fastapi-dls

## 安装与配置Truenas

安装truenas的教程网上可以找到很多，这里我就不再赘述了。在直通硬盘时有几点需要注意。直通硬盘有两种方式，第一种是映射直通，第二种是控制器直通，映射直通适用于硬盘较少的情况（小于6sata），将单个硬盘直通给虚拟机，缺点是不能查看硬盘smart信息。控制器直通就是字面意思。如果你使用nvme硬盘作为pve启动盘，我推荐大家使用控制器直通，这样性能更高。如果你用SATA硬盘作为PVE系统盘一定要注意，一旦虚拟机启动，所有硬盘就只能在虚拟机中识别了，pve就认不到了。所以不要直通控制器并设置truenas开启自启，否则😂 https://blog.csdn.net/weixin_48107526/article/details/131395172

### 建立数据集

我一共建立了三个数据集 pool_backup是一块4T机械硬盘，用于存放每晚的备份 pool_download是一块2T固态硬盘，用于存放truenas的app，临时下载的影片，以及pve的虚拟磁盘 pool1是3块8T机械硬盘组成的RAIDZ1阵列，主要存放重要资料，照片视频，还有电影电视剧等。

### SMB与NFS

这应该是两个最常用的文件共享工具了，在Windows中用smb，在Linux中用nfs进行文件互通，选择添加，添加你想共享的路径即可。不过在共享的时候要注意权限问题。

### 用户与权限

我们可以创建用户，自定义用户名和密码，并勾选samba认证，这样在Windows中就可以访问到nas中的文件了。 linux中的文件权限是十分复杂的，具体可以看这两位大佬的视频，讲的十分清楚明白。

### 安装应用

在安装应用前，我们可以把应用池设置到固态硬盘中 对于truenas有两个必备应用就是webdav和filebroswer，webdav用于数据同步。filebroswer用来浏览文件，因为truenas没有可视化的文件管理页面，所以这个应用就显得尤其重要。

### 硬盘休眠

点击存储，磁盘，我们可以看到硬盘名称以及其所在的池，点进选择编辑，我们可以看到电源管理项目，在这里可以设置多少分钟无活动后硬盘自动休眠。这里有一点要注意，如果设置休眠，硬盘的温度就无法查看了。

### 数据保护

数据清理和快照都打开，数据清理可以防止静默损坏情况，如果数据丢失或损坏，可以使用快照恢复到特定的时间点。

truenas23.10版本砍掉了onedrive同步功能，如果在用户凭证，备份凭据中没有你想进行云同步的站点，那么或许可以考虑用alist进行中转，对于云同步的使用方法，我们在后面的备份篇中详细讲解。

### 开启sftp:

为什么要开启sftp呢，因为我进行远程数据同步使用freefilesync软件，该软件只能使用sftp进行同步。如果大家使用webdav，这一步就没必要设置了。点击系统设置，服务，点击ssh的配置，选择TCP端口，勾选允许密码验证，然后使用用户账户密码登录即可开启SFTP。

### docker没了?

目前truenas23.10已经全面从docker转移到containerd，通过询问相关专业的同学得到的结论是，Containerd相当于精简版docker，如果要在truenas中安装docker容器也不是不行，就是命令可能有些区别。不过我还是建议大家另外开一个虚拟机安装docker，这样更加简单。

## 安装LXC容器

lxc容器是一个操作系统级别的虚拟化技术。它允许在单一的Linux系统上运行多个隔离的Linux系统（容器）。每个容器都有自己的文件系统、网络配置、进程空间等等，所有的容器都共享同一个内核。容器的启动速度非常快，内存消耗也很低 因为vGPU授权服务占用了443端口，所以在安装linux与ubuntu系统前，我们还要单独安装一个LXC容器，用于进行VGPU授权，授权完毕后关闭即可。

### 修改lxc源

执行如下命令修改lxc源

`cp /usr/share/perl5/PVE/APLInfo.pm /usr/share/perl5/PVE/APLInfo.pm_backsed -i 's|http://download.proxmox.com|https://mirrors.ustc.edu.cn/proxmox|g' /usr/share/perl5/PVE/APLInfo.pmsystemctl restart pvedaemon` 参考文献链接：https://www.bilibili.com/read/cv24553659/ 接着我们就可以在存储CT模板中看到很多系统镜像，我选择ubuntu23.04。 在创建CT容器时有一项无特权容器的复选框，如果取消勾选该容器就变成了特权容器，可以解锁nfs和smb共享。 听到这里可能有同学可能会问，是不是可以直接把应影音服务器安装在LXC容器里也可以呢，这样更节省资源，你说的没错。我最开始也是这么操作的，但后面我发现，特权容器不能进行快照备份到NFS，无特权容器又挂载不了NFS。这两点每一点都很头疼，所以我还是决定LXC容器就只做授权用，安装影音服务器我再创一个完全的虚拟机。如果有小伙伴们知道这个问题怎么解决，麻烦大家弹幕评论区内留言。 LXC容器安装好后，我们运行以下命令，安装docker，并启动授权容器备用。

## 安装Linux（影音服务器+照片备份服务器）

我选择的系统是ubuntu server22.04，分配了四核12G内存，128G固态以及被拆分的核显和独显。

### 新系统三部曲

安装好系统后我们进行三部曲 换源，下载速度更快 `bash <(curl -sSL <https://linuxmirrors.cn/main.sh>)` 开放root登录，这样就可以使用第三方ssh软件，这里我使用的是finalshell，输入命令更方便 `sudo apt-get install openssh-serversu - rootnano /etc/ssh/sshd_config` PermitRootLogin yes `systemctl restart ssh` 安装docker和portainer `bash <(curl -sSL <https://linuxmirrors.cn/docker.sh>)`

### 安装独显VGPU驱动

在安装完毕后还有比较重要的步骤就是给独显上驱动 还记得我们前面下载的压缩包吗，我们点击Guest_Drivers，把deb安装文件传到ubuntu里，直接运行安装即可 apt install ./NV 输入nvidia-smi，出现下面提示表示成功。 接着安装依赖

### plain



```plain
# 添加软件源
curl -fsSL <https://nvidia.github.io/libnvidia-container/gpgkey> | sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg \\
 && curl -s -L <https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list> | \\
   sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \\
   sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list

# 安装nvidia-container-toolkit
apt update
apt install -y nvidia-container-toolkit
nvidia-ctk runtime configure --runtime=docker
systemctl restart docker

# 测试，如果能正常输出显卡信息则安装成功
docker run --rm --runtime=nvidia --gpus all nvidia/cuda:11.6.2-base-ubuntu20.04 nvidia-smi
```

Plain text

Copy

如果能正常输出显卡信息则安装成功

#### 安装VGPU许可证

安装完毕后我们还要添加许可证 在shell中运行下面代码，注意把ip改为自己LXC容器的IP。

### plain



```plain
curl --insecure -L -X GET https://<dls-hostname-or-ip>/-/client-token -o /etc/nvidia/ClientConfigToken/client_configuration_token_$(date '+%d-%m-%Y-%H-%M-%S').tok
```

Plain text

Copy

### 影音服务器搭建

构成家庭影音服务器需要5个容器 nastool，jellyfin，qb，csf和jeckeet 逻辑图 当我在豆瓣加入想看时，nastool自动为该影视添加订阅，到了指定时间后，nastool会在jackeet中自动寻找该影片，如果找到了就会调用qb进行下载，如果没有找到就等到下次继续查找。影片下载完之后，nastool会自动向csf发送请求，查找中文字幕，并自动添加到影片目录中。此时电影还在临时下载文件夹里，我的下载盘是一块固态硬盘，需要把电影传到我的机械存储盘中，通过目录同步，nastool可以自动分类识别重命名，把这部电影放入机械盘-电影-外语电影中。如果下载的影片海报墙不完全，还可以调用tmm进行元数据搜索。之后我们打开jellyfin就可以看到一部刮削完毕，海报墙完整的影视了。

因为我之前使用DSM系统，所以比较习惯在根目录下建立docker文件夹，用于装载docker目录，大家可以根据自己兴趣来。docker文件夹建立后，建立mediaonline文件夹，在里面创建子文件夹，创建docker-compose文件然后运行docker-compose up -d

mkdir -p /docker/mediaonline

cd /docker/mediaonline nano docker-compose.yaml

### plain



```plain
version: '3.7'

services:
  nas-tools:
    container_name: nas-tools
    hostname: nas-tools
    image: nastools/nas-tools:latest
    ports:
      - "3003:3000"
    volumes:
      - ./nas-tools/config:/config
      - ./nas-tools/media:/media
    environment:
      - PUID=1000
      - PGID=100
      - UMASK=000
      - NASTOOL_AUTO_UPDATE=false
    restart: unless-stopped
  qbittorrent:
    container_name: qbittorrent
    image: johngong/qbittorrent:latest
    environment:
      - QB_WEBUI_PORT=8085
      - QB_EE_BIN=false
      - PUID=1000
      - PGID=100
      - UMASK=022
      - TZ=Asia/Shanghai
    ports:
      - "6881:6881"
      - "8085:8085"
      - "6881:6881/udp"
    volumes:
      - ./qbittorrent/config:/config
      - ./qbittorrent/downloads:/Downloads
    restart: unless-stopped
  jellyfin:
    image: nyanmisaka/jellyfin:latest
    restart: always
    container_name: jellyfin
    volumes:
      - ./config:/config
      - ./cache:/cache
#    devices:
#      - /dev/dri/card1:/dev/dri/card1
#      - /dev/dri/renderD128:/dev/dri/renderD128
    environment:
      - PUID=1000
      - PGID=100
      - TZ=Asia/Shanghai
      - NVIDIA_DRIVER_CAPABILITIES=all
      - NVIDIA_VISIBLE_DEVICES=all
    ports:
      - "8096:8096"
      - "8920:8920"
    labels:
      gpu: true
#    runtime: nvidia
#    deploy:
#      resources:
#        reservations:
#          devices:
#            - capabilities: [gpu]
  chinesesubfinder:
    container_name: chinesesubfinder
    hostname: chinesesubfinder
    image: allanpk716/chinesesubfinder:latest
    volumes:
      - ./chinesesubfinder/config:/config
      - ./nas-tools/media:/media
      - ./chinesesubfinder/browser:/root/.cache/rod/browser
    environment:
      - PUID=1000
      - PGID=100
      - PERMS=true
      - TZ=Asia/Shanghai
      - UMASK=022
    ports:
      - "19035:19035"
      - "19037:19037"
    logging:
      driver: json-file
      options:
        max-size: "100m"
  jackett:
    container_name: jackett
    image: linuxserver/jackett:latest
    environment:
      - PUID=1000
      - PGID=100
      - TZ=Asia/shanghai
      - AUTO_UPDATE=true
    ports:
      - "9117:9117"
    volumes:
      - ./jackett/config:/config
      - ./jackett/downloads:/downloads
    restart: unless-stopped
```

Plain text

Copy

影音服务器就搭建好了

> [!NOTE] 如果你跟我一样使用核显拆分与独显VGPU，可以直接使用该代码 如果你只进行核显拆分，请注释掉独显部分，要不然会报错 如果你是核显直通，请把这行命令中的1，dev/dri/card1:/dev/dri/card1中的1去掉即可。

目前我们的下载文件夹和影视库还都是绑定在本地，接着我们需要在portainer中修改位置

在truenas中建立两个共享文件夹，一个名为nastooldownload，用于存放临时下载，另一个命名为media当做影视库。 先把5个容器停止，在portainer中使用nfs挂载容器，先为存储取一个名，然后输入truenas的地址，接着输入文件存放的路径，一个存储就这么建好了 如法炮制两个存储库都建好了 进入portainer替换即可，点击EDIT，替换即可。 对于nastool的具体配置，也有很多现成的教程，大家搜索即可。 jellyfin里我们可以设置核显解码或独显解码，都可以正常调用显卡硬解。

### 照片视频管理

我认为，群晖自带的photos真的是无敌好用，但是如果你使用这套配置，群晖的photos就没办法使用了，所以我就一直在寻找可以替代photos的照片视频管理应用，目标就尽可能赶上群晖photos。

为此我体验了这6款应用 群晖photos piwigo photoprism liberphotos photoview immich mt-photos 接下来就从我个人实际体验出发，评价一下各款相册应用的优缺点。 我们可以打开下面的网址，也有大佬为此做了详细的对比。

首先我们来看piwigo，这是我用过最早的相册之一，我愿意称它为摄影师的相册管理软件，言外之意就是不太适合大众需求。它有非常多的主题，长相酷似个人博客，用来做分享非常好。 piwigo巨大问题就是必须手动导入图片至相册，对视频的支持不太友好，所以是更适合图片摄影师的一款应用。

photoprism是一款优秀的的相册管理软件，支持人脸识别，元数据，地点识别，ai识别，三端都有应用可以备份照片。唯一的不足就是时间线有些鸡肋，它不像群晖photos那样右边有一个小时间线可以快速跳转到具体的年月日，而且听说图片多了会卡顿。

接下来就是librephotos，这是我寄予厚望的一款应用，时间线，有，照片扫描，有，人脸识别有，AI词云，也有。问题是所有关于AI扫描的模型文件，都需要重新从网上下载，而这些模型大概率又下不下来。最要命的是librephotos的第三方安卓端，好像存在着某种bug，你让他不要用到流量上传，它好像没听到似的还是上传。如果使用官方的app，目前还只能看图，不能上传。不知道IOS端的APP使用情况如何。如果你可以接受，那么这款软件总体还是不错的。

接着就是photoview 这款应用更像是毛坯房，看起来作者们已经停更了有一段时间了。只支持相册浏览，和人脸识别，任何AI功能都没有，而且时间线跟photoprism一样也是半成品，好在支持本地扫描，如果不想要任何花里胡哨功能的话可以用这个。

immich是我认为，开源软件中最接近群晖photos的，最开始这个软件只支持从终端中导入外部库，后来更新了可视化导入外部库的功能，极大提升了这个软件的可用度。时间线，人脸识别，地点反查都有，手机app做的也非常美观，还支持调用NVENC转码视频，也支持使用ai大模型识别图片内容，可能是我自己的原因，在调用CUDA方面出了一些问题，目前这个功能还没体验到。美中不足的是网页端不支持中文，还有就是缩略图十分庞大，我怀疑我2T的照片视频他就要占去1T的缩略图。

最后，也是我目前决定使用的mt-photos，这款软件集合了immich和群晖photos的各项优点，本地化适配也非常好，支持中文CLIP，如果你想的话也可以调用独显，可以说是从群晖photos转过来的绝佳替代品，不过这款软件不是上面提到的开源软件，而是收费软件，这点就看大家权衡了 由于up的体验时间有限，可能上述有一些错误，还请大家批评指正，如果大家额也有推荐的相册软件也可以在弹幕和评论区中留言。 https://meichthys.github.io/foss_photo_libraries/

### Docker应用分享

我们继续来分享docker应用 对于书籍管理，我选用的是talebook，主要因为它支持opds，手机也可以直接连接观看

gitea，用来托管代码，我也是近期才学会git，还没有多人共同协作的计划，目前作为私人代码托管平台

readeck，稍后阅读应用，目前我把它当作书签来用，这款应用可以让你永久保留的网页，这点是我比较看重的

surveyking ，中文名叫卷王，是一款自搭建的在线调查问卷网站，因为最近也在写论文，所以http://survey.eccic.net/blog/hola/ alist 这也是一款神级软件，支持挂载，几乎所有网盘APP，还记得我们前面说到的truenas23.10把OneDrive砍了吗，没有什么是加一层解决不了的。用alist挂载OneDrive为webdav，就可以正常在truenas中同步了

npm 反向代理 如果你的家里有公网IP，并且想通过公网访问诸如jellyfin等应用，那么我推荐大家使用反向代理。传统的正向代理理解起来很简单，域名+开放的端口号即可进入，但如果应用多了，记忆端口号也十分麻烦，而且还要单独配置SSL证书。使用npm反向代理就可以帮我们一键配置二级域名，自动生成ssl证书，可以让访问更加快捷安全。

最后一个容器就是uptimecuma，如果你的服务器突然挂逼了，或者突然无法访问了，umtimecuma就可以自动给你发送一封邮件提醒。方便你找到原因，及时处理。

## Windows云游戏服务器部署

下面就到了大家期待的Windows游戏服务器安装

> [!NOTE] 前排提醒 如果你跟我一样想用windows进行游戏的话，在不进行任何配置，打开一些网游大概率会出现虚拟机检测的标识，我建议大家跟我选择一样的操作系统win10（22h2）并跟我一起设置。

我们先要提前上传好ISO镜像，一个是win10镜像，一个是virtio驱动，不然后续可能会出现识别不了硬盘，出现没网的情况。 点击创建虚拟机，名称随便填写，这里我们选择win10镜像，机型选择Q35，bios选择UEFI，TPM需要勾选上。磁盘选择SATA，之前也使用过SCSI，不过在过虚拟机检测时出现了一些问题，我还是建议大家选择SATA，磁盘大小大家根据自身情况选择，CPU同样，类别选择host，内存修改一下，后面默认即可，记住，暂时先不要启动 点击硬件，添加PCI设备，我们把显卡加上，我们选择4Q，相当于给显卡分配4G显存，当然，你也可以给它分完全8G，只要把Linux系统中的显卡删除即可。 接着把virtio驱动光盘添加上。 进入选项，把启动项调一下，留一个sata磁盘就行。 接下来我们在shell中输入下面代码 cd /etc/pve/qemu-server/，进入该文件夹，输入ls，找到你虚拟机的序号的文件。使用nano进行编辑nano 100.conf 在第一行添加代码args: -cpu host,hypervisor=off，相当于告诉Windows我不是虚拟机，这样就可以启动游玩绝大多数网络游戏，少数网络游戏除外，也有更详尽去虚拟化方案，大家可以参考李晓流大神的文章自行测试。 系统装完后大家肯定会发现没网，而且pve中的关机也不好使，我们打开virtio驱动光盘 双击64位virtio驱动安装即可，这样电脑就有网了

接下来就要安装显卡驱动了，还记得最初我们下载的驱动安装包吗，没错这里面也有Windows版驱动，我把它放在了truenas共享文件夹中。现在我们就来映射网络驱动器。打开此电脑，点击映射网络驱动器输入反斜杠\\<ip地址>\+数据集名称，接着输入账号密码，记住，是自己创建的账号密码，不是admin也不是root。 如果提示需要权限进行操作，我们还要在truenas中给自己一下权限。 接着我们双击驱动安装即可

安装完毕后我们还要添加许可证 在管理员cmd中运行下面代码，注意把ip改为自己LXC容器的IP。 curl.exe --insecure -L -X GET https://<dls-hostname-or-ip>/-/client-token -o "C:\Program Files\NVIDIA Corporation\vGPU Licensing\ClientConfigToken\client_configuration_token_$($(Get-Date).tostring('dd-MM-yy-hh-mm-ss')).tok" 重启Windows，看到已获得NVIDIA许可证，驱动就装好了。 但目前在控制台中访问不太方便，我们可以尝试安装parsec，安装完毕后测试可以打开后，我们就可以把虚拟机中的显示关了。 这样一台游戏服务器就搭建完成了 在Docker服务都正常运行的情况下，CPUz单核成绩438.7分，多核1774.9分，差不多是i7-7700水平，算上虚拟化开销还算不错了。显卡方面3dmarktimespy，显卡分4265分，得分在10606G与980之间，原神高画质跑图帧数在50帧左右，古墓丽影暗影特效全高52帧，鲁大师跑分仅供参考，基本达到了预期水平。

游戏测试完毕后，又存在一个问题，云游戏说得好，但是有概率parsec在公网中连不上，这怎么办啊？

接下来就到了关键的内网穿透教学环节了！ 我们可以新建一个虚拟机，跟前面部署ubuntu虚拟机一样，我是因为想把内网与外网服务分开，所以又新建了一个虚拟机，如果大家没有我这种需求的的话，完全可以在以及建好的ubuntu虚拟机中操作

虚拟机安装完毕后，我们快速搭建一个面板服务器，这里我选用的是1panel。进入官网，复制一键部署代码，粘贴跟着操作流程一步一步走就行 curl -sSL https://resource.fit2cloud.com/1panel/package/quick_start.sh -o quick_start.sh && sudo bash quick_start.sh 1panel是一个容器化面板，安装好1panel之后docker也就自动安装好了 我们先进入taliscale官网，注册或登录一个账号 打开设置（https://login.tailscale.com/admin/settings/general）点击key选项，打开右侧的Generate auth key，将里面的Reusable打开确认后点击copy，将秘钥复制到记事本保存备用 接着我们回到ubuntu虚拟机，新建docker文件夹，在文件夹内创建taliscale文件夹， 接着运行下面代码

### plain



```plain
docker run -d
--name=tailscaled
-v /var/lib:/var/lib
-v /dev/net/tun:/dev/net/tun
--network=host
--cap-add=NET_ADMIN
--cap-add=NET_RAW
--env TS_AUTH_KEY=xxxxx
--env TS TS_ROUTES=192.168.x.0/24
tailscale/tailscale
```

Plain text

Copy

将原先保存的密钥复制到TS_AUTH_KEY=后面 将路由器主机网段填写到TS_ROUTES=后，比如我路由器网关是192.168.123.1，我就填写192.168.123.0/24 回车运行即可 此时我们登录1panel后台，就可以看见taliscale已经成功运行 回到taliscale网页端，将主机的Edit route settings打开，关闭自动过期。主机端就设置好了 接着设置你的常用电脑，下载完客户端后安装登录，关闭自动过期。 你会惊奇的发现，即使你连着手机热点，依然可以直接通过局域网IP访问家里的服务，parsec也是如此，就跟在局域网内一样。

1panel还有很多服务可以一键安装，比如个人博客，我的世界服务器面板，还有各种有用的容器，受限于时间，我就不在这期视频里讲了，如果大家有需要，麻烦弹幕评论私信告诉我，我也会继续为大家制作相应内容。

群晖 不是安装PVE后就必须使用truenas来做文件存储中心，你当然可以安装unraid，群晖DSM这些系统当作你的nas服务器，而且还更加简单。 可能有同学又有疑惑，upup，你都装了truenas了还装群晖干什么呀。唉，还记得前面我提了一嘴的备份吗？

all in boom？no 目前公认较好的备份原则 就是321原则， 3：至少保留3份（一份主备份，两份副本）。 2：将备份保存到两个不同的存储设备或位置。 1：在不同的位置至少保留一份备份副本。 目前手机拍摄的照片，可以通过mt-photos自动传到nas上 使用相机拍摄的视频，照片，剪辑的工程文件，可以通过freefilesync，goodsync等同步软件备份到nas上。

%% truenas自身也可进行云同步，我们可以通过alist文档中绑定onedrive的教程一步一步操作， 最后在truenas中添加alist的云凭据备份即可。 %%

PVE中的虚拟机，也可以设置自动备份，我从truenas的备份盘通过NFS挂载了名为backup的存储到PVE上，设置为每天凌晨两点自动备份，这样所有PVE虚拟机的备份都保存在了truenas中，只要truenas阵列不损坏，PVE的虚拟机就永远可以恢复。 那么问题来了，如果阵列损坏了怎么办？ 当然这已经是非常极限的想法了，除非我一次性坏两块硬盘阵列才会损坏。不过也有办法，我们还可以进行云同步，把所有数据，包括备份镜像，通过alist中转，上传到OneDrive上，具体链接onedrive的方法大家可以看alist文档，里面介绍的非常详细，按步骤抄作业就行。

点击添加云同步任务，方向选择推送，传输模式大家根据自身需要选，我选择复制，接着选择你想同步的文件夹，下面的传输其实就是任务并行数量，在这里要注意，如果你的上传带宽比较小的话建议选择最小即可，因为rclone的传输方式不支持断点续传。如果传输超大文件时意外中断会很难受。

如果你想更精细的控制带宽，可以设置带宽限制，我的设置是每日0:00开始限制3mb的上传速度，每日12:00时限制2mb。 针对重要文件可以设置加密。 这应该是目前最为经济的321备份法实践了。 但是，不出意外要出意外了哈 面对超大文件（>100G），truenas使用alist中转可能会出现405 Method Not Allowed的情况，查询相关问题后发现可能是OneDrive自身问题，但我之前用群晖怎么就没遇到过这个问题呢？所以我就开始了实验，从truenas中分隔一块1TB的硬盘给群晖，接着初始化，安装群晖cloud sync，使用webdev将pve备份镜像全部拉到群晖中，注意这里raw和qcow2的虚拟磁盘要排除在外，备份他们没有任何意义。最后再将pve备份镜像全部推到onedrive中，这么一实践还真没发现问题。只要不超过250G的大文件都可以正常备份。所以我估计应该是的接口的问题。

最后，还可能有一种情况，如果PVE系统盘崩了怎么办？你可能会说，唉，没事的，系统盘有什么用，只要虚拟机在就行。 的确，对于pve虚拟机本身，重新配置并不难，只需要重新看一遍这个视频就行。 但是，有没有一种方法，把虚拟机本体也备份了，这样不是连重新配置的步骤都省了吗？ 还真有 如果你也安装了DSM系统，可以使用里面的Active Backup for Business套件，直接备份Linux系统，最后通过镜像进行还原。但是 https://www.synology.cn/zh-cn/dsm/7.2/software_spec/abb 但目前abb只支持到debian11，内核支持到5.15。我目前的debian版本是12.5，内核版本是6.5.13-1-pve 显然不行 cat /etc/debian_version uname -r 之后还想到可以用再生龙克隆系统，但是必须要停机 有没有不停机还能备份系统本体的软件？ 还真让我找到了 veeam这款软件可以在系统开机的情况下备份，而且还有免费的社区版，还原也是通过镜像还原，我将veeam的备份目录也设置到了pve备份目录中，这样可以一同进行云备份。

不知道大家有没有发现，我并没有把网络放在pve上，因为我知道，只要网络不崩，这台服务器就永远不会boom。

ok本期PVE开荒教程到这里就结束了，感谢大家能看到这里。原本这期的稿子早就写完了，但是看到了大家的评论和弹幕发现的确有很多关键的点需要点到，原本写好的稿子改了又改，加了又加，希望大家一键三连支持一下。经过两期的铺垫，终于来到最后一期云游戏篇，横跨3000公里的云游戏体验究竟如何？希望大家一键三连支持一下up主，我们下期视频拭目以待。