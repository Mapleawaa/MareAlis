---
title: >-
  史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI
  /SR-IOV直通
updated: 2024-06-09 07:52:36Z
created: 2024-06-09 07:50:59Z
latitude: 31.29897900
longitude: 120.58529000
altitude: 0.0000
---

# 史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通

## 前言

我 PVE 上面常驻的一些虚拟机包括：iKuai、OpenWrt、Debian、CentOS、Windows、群晖等，首先iKuai作家里的为主路由，负责网络拨号、宽带叠加、动态域名、和 DHCP 服务器等一些功能。

OpenWrt 作为旁路由，负责特殊网络需求的一些处理，Debian 共享 PVE 的核显，安装 Emby，作为家里的影音服务器。CentOS 用来测试一些脚本。

Windows 则是分配了一个 SR-IOV 虚拟化的核显，作为常开的一台设备，在家或是外地用远程桌面进行连接，前提需要一个公网IP。其他的虚拟机我们就不一一说明其功能了。

## 准备工作

1、PVE 平台已经安装调试完毕

2、提前下载一些固件（ <ins>iKuai 固件</ins>）（<ins>OpenWrt 固件</ins>）

3、RR 大佬的群晖引导包 GitHub 下载地址：<ins>点击下载</ins>

## 安装 iKuai

### 下载引导包

下载 iKuai 最新固件：<ins>点击下载</ins> ，我们下载 `ISO 64` 位的。

### 自定义虚拟机

上传镜像包到 PVE - local - ISO镜像 - 上传

<ins>![](../_resources/97632084.jpg "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

新建虚拟机，根据自己的需求直通网络设备，我最终的设置如下图：

<ins>![](../_resources/3244583192.jpg "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

（安装完以后，请移除 `CD/DVD` 设备，记得安装时选择从 CD 启动，安装完毕选择从 `scsi0` 启动，勾选 开机自启动）

<ins>![](../_resources/3156502731.jpg "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

### 分配 PCI 设备

直通的三个设备是二个 2.5G 网口、一个 10G 网口。

分别作为 电信 WAN 口（2.5G）、联通 WAN 口（2.5G）、LAN 口（万兆）

### 更多关于 iKuai 的设置

其他的关于 iKuai 的设置，请参考 ：<ins>66 期视频</ins> 、<ins>75 期视频</ins>

更多的玩法，或是需求，请老铁们留言。

## 安装 OpenWrt

### 下载 OpenWrt 固件

### 安装 OpenWrt

上传固件到 PVE 的 root 目录。

执行以下命令，进行磁盘的挂载：（其中的 `103` 为虚拟机编号， `openwrt.img` 为固件文件名，自行修改）

根据存储集而定 如果删除了LVM分区，那就为Local

```js
qm importdisk 103 openwrt.img local-lvm
```

命令执行完毕，会在虚拟机的设备页面出现一个 `未使用的磁盘0` ，双击，并设置 `总线/设备` 为 `SATA` 。

<ins>![](../_resources/1591719840.jpg "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

设置 选项 - 引导顺序 为 `sata0` ，开机，跑完代码以后，输入 `vi /etc/config/network` 进行 网络的设置和规划。

<ins>![](../_resources/111927887.jpg "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

按键盘上面的 `i` 键，进入插写模式，修改完毕以后，按键盘 `ESC` 退出插写模式，再次输入 `:wq` ，保存刚才的设置。确认无误以后 `reboot` ，进行重启

<ins>![](../_resources/1706935342.jpg "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

输入设置的 IP ，登录 OpenWrt，相关的设置，我们原来讲过很多了。可以去频道页面观看其他有关 OpenWrt 的视频。

### 设置 OpenWrt

下图固件为 <ins>本站编译的固件</ins> 。（固件名字：`旁路由精简版` ）

<ins>![](../_resources/489837338.jpg "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

## 安装 Windows11

### 下载 Windows11 安装包

下载 Windows11 安装包：<ins>点击跳转下载页面</ins> （下载 Windows 11 磁盘镜像 ISO 文件）

<ins>![](../_resources/858803465.png "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

### 下载虚拟机 VirIO 驱动

Windows VirIO 驱动程序：下载 <ins>最新的稳定版</ins> ，也可以 <ins>下载 ISO 的最新版本</ins>

### 下载 Windows11 最新驱动

在必须满足虚拟机配置的前提下：安装当前最新的驱动，下面2个，二选一自行测试。

（ 本次下载的 Windows11 已经包含了驱动 ）

<ins>英特尔® Arc™ 和锐®炬® Xe 显卡 - BETA - Windows\* (intel.cn)</ins>

<ins>英特尔® Arc™ 和锐炬® Xe 显卡 - WHQL - Windows\* (intel.cn)</ins>

### 新建 Windows 虚拟机

> 把下载下来的 Windows 的 ISO 镜像包（ `Win11_23H2_Chinese_Simplified_x64v2.iso` ）以及 Windows VirIO 驱动程序 （ `virtio-win-0.1.240 .iso` ），上传到 PVE - local - ISO镜像

<ins>![](../_resources/4069389727.png "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

新建虚拟机，具体配置根据自己的需求

<ins>![](../_resources/1990678762.png "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

<ins>![](../_resources/632416537.png "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

更多相关的设置说明，还是请观看 <ins>本期视频</ins>，最终配置完成如下参数。（若是不看视频，请详细核对参数）

<ins>![](../_resources/4268058014.png "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

找到虚拟机选项，把引导顺序改为如上图中的 `ide2` ，也就是选择从 Windows 安装程序的 CD/DVD 进行引导

### 安装 Windows

安装过程中会发现找不到磁盘，我们点击 加载驱动程序 ，点击 CD - virio-win - amd64 - w11 ，如下图：

<ins>![](../_resources/619335181.png "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

<ins>![](../_resources/2820929368.png "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

程序复制完毕以后，重新启动的时候，我们停止虚拟机，选择从硬盘启动，因为我们的网卡选择的是 `Virtio 虚拟化`，截止到目前，还没有驱动网卡，若你是选择的 `E1000` 等型号的网卡，请先移除网卡在开机，若你是想跳过微软的联网验证和绕过Microsoft账户登录要求的话。

来到网络界面，按键盘上面的 `Shift键 + F10键` ，调出 CMD 窗口，单击窗口输入 `oobe\bypassnro` 并回车

现在安装程序会重启，并再次来到 连接网络界面，选择 `我没有 Internet 连接` 来跳过此操作，继续点击 继续执行受限设置 。

### 设置 Windows

安装 `Virtio` 驱动程序

<ins>![](../_resources/3123540310.png "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

安装 Guest-Agent （ 也就是 QEMU ）

<ins>![](../_resources/3405679089.png "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

### 分配磁盘空间

继续分配刚才没用完的磁盘空间

<ins>![](../_resources/891507458.png "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

打开任务栏管理器，`UHD 770` 一些正常！

### Windows 远程连接

打开设置里面的 远程桌面连接，以后我们就可以远程连接这台 Windows 了。

Windows 远程连接，推荐使用自带的工具进行远程连接。

而 MacOS 也是推荐使用微软的 Microsoft Remote Desktop 进行连接，相关的参数可以参考 <ins>本期视频</ins>，或是自己研究。

PS：MacOS 需要使用非国区账号进行在 AppStore 里面下载！（当然，你可以找到安装包当我没说）

<ins>![](../_resources/212004673.png "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

### SR-IOV 驱动 43 问题

两种方法

第一种：尝试把虚拟机的显卡改为 `无`，只是这样虚拟机就只能通过远程连接，而在 PVE 控制台中就无法显示了

第二种：尝试修改虚拟机配置文件，在配置文件里面加入如下代码，最后的 `0x2`，是虚拟出来的第二个显卡。`02.0` 表示核显的位置。编辑 `/etc/pve/qemu-server/104.conf` （ 其中 101 是虚拟机 id ）

```js
args: -set device.hostpci0.addr=02.0 -set device.hostpci0.x-igd-gms=0x2
```

## 安装黑群晖

### 下载引导包

我们安装黑群晖的 `SA6400` 版本，因为其内核对新一代的 CPU 支持很好。

下载 RR 的黑群晖引导包：<ins>点击下载</ins>（截止到目前最新的版本是：`rr - 24.4.5` ，最早的引导包或许不包含 SR-IOV 核显驱动）

### 自定义虚拟机设备

新建虚拟机，根据自己的需求，我这边直通给它一个 `SR-IOV` 的核显 ，`0000:00:02.1`，编号 26，记得，核显最上面的 编号0 的第一个设备，不要直通给任何设备。

> 因为这边勾选了`主GPU` 等一些选项，所以我们的显示设备需要改为 `VirtlO-GPU（virtio）` ，不然我们无法在虚拟机的 `控制台` 中获取系统画面。

我这边最终参数如下图：

<ins>![](../_resources/2064818108.jpg "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

### 设置虚拟机硬盘

上传 RR 引导包到 root 目录，执行如下命令（其中的 101 为你虚拟机的编号）

```js
qm importdisk 101 rr.img local-lvm
```

上述命令把 img 文件映射为虚拟机的磁硬盘，命令执行后，会在虚拟机设备栏多出一个 `未使用的磁盘0` ，双击该磁盘，在 `总线/设备` 中选择 `SATA` 类型，点击添加。

点击 选项 - 引导顺序，设置从 sata0 启动

我这边是为了演示，所以设置了一个 sata1 的虚拟磁盘（100G），如你是有物理磁盘，可以使用 sata 直通 或是 磁盘直通 的方式，在虚拟机里面进行挂载。

我这边 sata直通 比较麻烦，因为还有其他的设备在 sata 上面，所以，我这边选择 磁盘直通 的方式，具体命令如下：

```js
ls -l /dev/disk/by-id/      # 查看所有磁盘 ID
```

记录 磁盘ID，例如下图中的类似 `ata-ST16000NM000J-2TW103_ZR5DJV3T` 、 `nvme-aigo_NVMe_SSD_P7000Z_4TB_2023102400134` 等

<ins>![](../_resources/1639420223.jpg "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

使用如下命令进行挂载，记得更改 磁盘类型 为 sata，更改 `nvme-J.ZAO_5_SERIES_1TB_SSD_MCM439T000642` 为你希望挂载的磁盘编号。

```js
qm set 101 -sata1 /dev/disk/by-id/nvme-J.ZAO_5_SERIES_1TB_SSD_MCM439T000642
```

### 自定义引导包

开机，通过 RR 引导包，到达如下界面，根据 `控制台` 中的提示内容进行设置，其中的注意事项请 <ins>**观看视频**</ins>

<ins>![](../_resources/2739547857.jpg "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

选择 型号 - 版本 - 内核（我用的 `custom` 内核） - 设置 `Comline` - 自定义 `SN/MAC` （推荐某宝购买 SA6400 全白系列号，一定记得问商家怎么注册外区账号） - 编译引导 - 启动

<ins>![](../_resources/3580705243.jpg "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

### 检测 SA6400 核显

接下来的设置很简单，有需要可以观看一次 本期演示视频，减少踩坑的次数。

输入如下命令 `ls /dev/dri` 查询核显是否存在

```js
bobo@TEST:/$ ls /dev/dri
by-path  card0  renderD128
```

若是没问题，则会返回如上回显，黑群晖 `SA6400` 核显驱动成功

### 黑群晖洗白检测

点击群晖 控制面板 - 信息中心 ，点击登录账号，根据你的群晖账号进行填写。若是在 RR 引导 界面没有正确设置 SN/MAC，则这一步无法正常登录，请检查你的全白或是半白的 SN/MAC。

> 推荐一定不要开启 `QuickConnect` ，慎重！慎重！慎重！

正常登录后如下显示：

<ins>![](../_resources/1373753883.jpg "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

### 安装相关套件

套件中心 - 所有套件 - 多媒体，找到 `Advanced Media Extensions` 套件。若是已经成功洗白（也就是 RR 引导包中的 SN/MAC 正确，并且已经在信息中心登录非国区群晖账号），安装成功后，如下图：（若不能安装，应该就是洗白的问题）

<ins>![](../_resources/1219594968.jpg "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

安装 多媒体套件 - Synology Photos ，打开 共享空间，并启用 空间人物相册 及 主题相册。

<ins>![](../_resources/3348362568.jpg "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

我们上传图片，人脸识别成功，如下图，更多相关的设置，请观看 <ins>本期演示视频</ins>

<ins>![](../_resources/3978286494.png "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

### 推荐安装套件

若是在 PVE 里面不能正常的关闭黑群晖，可以尝试安装 “我不是矿神” 套件中心里面的 QEMU Guest Agent 这个套件。

可以有效的解决 PVE 里面黑群晖不能关键，不能重启等一些问题。

黑群晖安装成功，人脸识别、主题识别等一切功能正常。

## 安装 Emby

### 安装相关套件

打开群晖 套件中心 - Container Manager 安装该套件。

打开群晖 控制面板 - 终端机和SNMP - 启动 SSH 功能。

### 拉取 Emby 镜像

SSH 工具，连接群晖服务器，输入如下代码拉取 docker 镜像。

```js
sudo -i   # 输入管理员密码，获取 root 权限
docker run \
    --name EmbyServer \
    --net=host  \
    -v /volume1/docker/Emby:/config \
    -v /volume1/电影电视剧:/电影电视剧 \
    -e TZ="Asia/Shanghai" \
    --device /dev/dri:/dev/dri \
    -e UID=0 \
    -e GID=0 \
    -e GIDLIST=0 \
    -e HTTP_PROXY="http://10.0.0.3:7890/" \
    -e HTTPS_PROXY="http://10.0.0.3:7890/" \
    --restart always \
    -d emby/embyserver:latest
```

代码解读：

```js
/volume1/docker/Emby:/config  ## 是Emby的存放路径，必须保证 /volume1/docker/Emby 文件夹存在，若是不存在，请自行建立。
/volume2/电影电视剧:/电影电视剧  ## 是群晖电影目录的路径
--device /dev/dri:/dev/dri   ## 分配核显，若是没有核显，可以删掉
-e UID=0
-e GID=0
-e GIDLIST=0     ## 权限设定，若是不明白，请：https://hub.docker.com/r/emby/embyserver
-e HTTP_PROXY="http://10.0.0.3:7890/"     ## 为Emby开启代理，博主的代理是 OpenWrt 上面的 OpenClash
-e HTTPS_PROXY="http://10.0.0.3:7890/"    ## 为Emby开启代理，若是没有代理，请删除这两行代码
-d emby/embyserver:latest  群晖官网的镜像
若是没有密钥，有开心版本的地址为：lovechen/embyserver:latest，请自行替换
```

若不想开启 docker 版本的 Emby http 代理，也是可以在 iKuai 中设置群晖的 NAT 规则，以达到搜刮影音资源的目的。

运行代码如下：

<ins>![](../_resources/2860291153.jpg "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

### 设置 Emby

若是你对 Emby 其他设置不是太明白，可以观看这期视频：

<ins>构建完美家庭私人影音库！软路由、OpenWRT开机Rclone自动挂载阿里云盘，Docker Emby 开心版、支持服务器硬解！</ins>

打开 [http://群晖IP+8096](http://xn--IP+8096-4i4o353p)，对 Emby 进行设置，相关设置请观看 <ins>本期视频</ins>

<ins>![](../_resources/1670319381.jpg "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

设置完毕后，若是正版 Emby ，输入密钥进行激活，我们看看转码界面，首选硬件解码器正常！

### 硬件解码测试

<ins>![](../_resources/2760261005.png "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

Copy 几部电影进去看看，看看是否能正常解码。

<ins>![](../_resources/1427435986.png "史上最全！PVE安装iKuai、OpenWRT、Windows11、Emby、黑群晖等保姆级教程！Windows、群晖、Emby核显HDMI /SR-IOV直通")</ins>

至此，Emby 也是 OK 的，若是你对 Emby 其他设置不是太明白，可以观看这期视频：

### 更多关于 Emby 的设置

<ins>构建完美家庭私人影音库！软路由、OpenWRT开机Rclone自动挂载阿里云盘，Docker Emby 开心版、支持服务器硬解！</ins>

## 后记

整体来说，PVE上面虚拟机的搭建，也是挺简单的，估计很多小伙伴也就是虚拟机的参数、或是一些命令不会而已。

前面的一些内容也是讲的比较快，大家若是在iKuai或是OpenWrt的安装或是配置过程中遇见什么问题，也是欢迎在频道里面搜索相关的关键字，来获得更多的视频支持。