# Star System | 我的第一台HTPC主机

从去年开始折腾ALL IN ONE，并且在22年左右购买了一台倍控的4口软路由作为入门的第一台小主机，都说小主机是每个爱折腾的人第一台入手的，同时也是学出结果后第一个嫌弃的，各种拓展性和性能发挥问题，是折腾在“家用服务器”这个领域里最大的阻碍。于是，在沉淀三年后，2025年龙年，我决定用手头和购买的硬件，在2025年使用价格足够便宜的PC硬件，组装出我的一台真正意义上的HTPC主机。

## 主机硬件清单
|硬件数量| 硬件 | 型号 | 价格(CNY) | 功耗 | 备注 |
|-|-|:-:|-|-|-|
|1 | CPU | Intel Core i3-8100T 4C4T | 105 | 65W满载 空载10W | 购买于淘宝 15元优惠券 |
| 2 | 主板 | ASRock 华擎 Z370 Pro4 ATX板型 | 160 | 未知，但是ATX板型相比普通的板型，拓展性提升明显，但是功耗就是令人头疼 | 购买于闲鱼 |
| 3 | 内存 | 金百达DDR4 3200 8G 海力士颗粒 | 50 | 未知 | 朋友♂交易 |
| 4 | 内存 | 金百达DDR4 3200 8G 海力士颗粒 | 50 | 未知 | 朋友♂交易 |
| 5 | 系统盘 | PCIE4.0 256G TLC 固态硬盘 | 100（不计入总价） | 2W | 群联E10方案原厂，很早之前买的，通电时间200小时超级新 |
| 6 | SSD | 西数SN720 512G PCIe3.0 固态硬盘 | 0 | 2W | 老联想笔记本拆机盘，健康度还算不错，与其放在硬盘盒里吃灰，不如丢进主机里锻炼一下 |
| 7 | 机械盘 | 希捷企业级 ST1000NM0033 * 2 | 0 | 工作中 8W 空闲5W | 家父原先购买，属于希捷老技术盘体，2016年左右出厂 |
| 8 | 机械盘 | 希捷监控级 ST4000VX015 海康威视OEM | 420（不计入总价） | 不确定 | 购入于淘宝，2023年8月购买，里面有点数据，是NTFS格式的 |
| 9 | 机械盘 | 希捷监控级 ST4000VX015 海康威视OEM | 378 | 不确定 | 2025年2月12日购买,全新，新啊，很新啊（赞赏 |
| 10 | 机械盘 | 西数WD5000AAKX 500G | 0 | 未知 | 2012 使用至今，除了因为意外断电事故导致 SMART 数据丢失重建之外都没什么问题。|
| 11-12 | 机械盘 | 西数WD5000AAKX 500G * 2 | 0 | 未知 | 淘宝购入的清零盘，出厂日期应该也不早了 |
| 13 | 机箱 | 先马SAMA 影子战士 塔式机箱 | 40 | ？这有啥功耗？ | 购买于闲鱼，本地捡漏 |
| 14 | 散热器 | AVC铜体压铸下压式 | 16 | 小风扇呼呼呼 算个1W | 购买于闲鱼捡漏 |
| 15 | 几个风扇 | 乔思伯12CM风扇 5个 | 0 | 0.5W一个 | 上面买机箱送的 |
| 16 | 电源 | 驿晨宇 玄武500Kill | 135 | 最大500W输出，单路+12V最大41.7A | 小牌子，但是便宜啊，老板在B站有号，烧硬件包赔！ ！|
| 17 | 机箱附件 | 一个光驱位硬盘架 | 20 | 拼多多 |
| 18 | 机箱附件 | 一个风扇控制器 | 10 | 拼多多 | 
| | | 总价格| 964 | 


## 系统构架

```mermaid
graph TB;
	S1T[希捷企业级ST1000NM0033]
	S1T1[希捷企业级ST1000NM0033]
	S4T1[希捷监控级 ST4000VX015 旧]
	SSD1[西数SN720 512G PCIe3.0 固态硬盘]
	P[Proxmox VE]
	FNOS[飞牛NAS]
	WIN[WindowsServer]
	AHCI[SATA控制器]
	AHCI-M[马牌SATA控制器]
	
	subgraph **PVE**
	P <--> FNOS
	WIN <--> P
	AHCI-M <==直通==> WIN

	
	subgraph 飞牛
	FNOS <--虚拟网桥--> WIN
	AHCI <==直通==> FNOS
	AHCI <-.单盘存储相册拍摄数据素材.-> S1T
	AHCI <-.存储电影番剧归档备份.-> S1T1
	AHCI <-.BT PT下载.-> SSD1
	SSD1 ---达到分享率后归档--- S1T1
	end

	subgraph Win
	S4T1 <---> AHCI-M
	FNOS <-.SMB共享挂载定期热归档存储相册等重要数据.-> S4T1
	end
	end
	subgraph 异地备份

	ALIOSS[阿里云OSS - 归档存储]
	TENOSS[腾讯云OSS - 冷数据低频存储]
	S3A[AMS S3云存储 - Archive]
	FRIEND[朋友家一块1TB硬盘 - 800Km外]
	BAK[备份]
	FNOS <--> BAK
	
	ALIOSS <-.1:1备份.-> TENOSS
	BAK <--> ALIOSS
	S3A <-.敏感数据增量备份.-> BAK
	FRIEND <--.主要灾备 存放仅此一份的图片文稿 定期上电存放干燥箱.--> BAK
 	end	
```



## 虚拟机安排

PVE-**Selunaville**

	- 飞牛OS-**Meteor**
	- Windows Server-**Quasar**
	- LXC-Nginx\MongoDB\Redis-**Hyperion**
	- LXC-HomeAssistant-**Home**
	- LXC-RSync Server-**Roche**
	- 不知道塞点啥好了

```mermaid
graph TB
    %% 核心硬件层
    HW[硬件层] -->|连接| PVE[Proxmox VE 宿主机]
    HW -.-> CPU((i3-8100T))
    HW -.-> GPU{{核显 UHD630}}
    HW -.-> HDD1[企业级1TBx2]
    HW -.-> HDD2[监控级4TBx2]
    HW -.-> SSD[512G SSD]

    %% 虚拟化层
    PVE -->|直通核显| FN[飞牛NAS]
    PVE -->|直通SATA控制器| Win[Windows Server]
    
    %% 服务层
    FN --> Media[媒体中心]
    FN --> Photo[相册管理]
    FN --> Download[下载工具]
    Win -->|SMB共享| Archive[热归档存储]
    
    %% 存储流向
    HDD1 -->|基础存储| FN
    SSD -->|下载缓存| FN
    HDD2 -->|冷备份| Archive
    GPU -->|硬件转码| Media
    
    %% 备份体系
    Backup[备份策略] --> Cloud[云存储]
    Backup --> Local[本地副本]
    Backup --> Remote[异地硬盘]
    
    Cloud --> Ali[阿里云OSS]
    Cloud --> Ten[腾讯云COS]
    Remote --> Friend[朋友家1TB]
    
    FN -->|加密同步| Backup
    Archive -->|定期归档| Backup
    
    %% 样式美化
    classDef hardware fill:#f9f2ec,stroke:#eb8100;
    classDef virtual fill#e6f3ff,stroke:#0066cc;
    classDef service fill#e8f5e9,stroke:#4CAF50;
    classDef storage fill#fff3e0,stroke:#ffa726;
    classDef backup fill#fce4ec,stroke:#e91e63;
    class HW,CPU,GPU,HDD1,HDD2,SSD hardware
    class PVE,FN,Win virtual
    class Media,Photo,Download,Archive service
    class HDD1,HDD2,SSD storage
    class Backup,Cloud,Local,Remote,Ali,Ten,Friend backup
```