---
title: OpenWRT+Emby构建完美家庭私人影音库！软路由、OpenWRT开机Rclone自动挂载阿里云盘，Docker Emby 开心版、支持服务器硬解！
updated: 2024-06-09 07:55:06Z
created: 2024-06-09 07:53:55Z
latitude: 31.29897900
longitude: 120.58529000
altitude: 0.0000
---

## 准备工作

- 1、软路由（旁路由）一台，平台不限，本期视频以 X86 平台作为演示
- 2、阿里云账号一个（这个大家都有吧）

相关工具下载：

- 本期视频使用的软路由固件：[点击下载](https://v2rayssr.com/openwrt.html)

## 软路由阿里云盘设置

### 获取 Refresh Token

进入软路由的 服务 – 阿里云盘WebDAV ，启用并双击 Refresh Token ，登录手机 阿里云盘，扫描二维码，获取阿里云的登录 Token。

## <img decoding="async" class="alignnone size-full wp-image-110938 lazy entered loaded jop-noMdConv" src="https://v2rayssr.com/wp-content/uploads/2023/02/1222.png" alt="OpenWRT+Emby构建完美家庭私人影音库！软路由、OpenWRT开机Rclone自动挂载阿里云盘，Docker Emby 开心版、支持服务器硬解！" width="700" height="664" data-src="https://v2rayssr.com/wp-content/uploads/2023/02/1222.png" data-ll-status="loaded" style="max-width: 100%; height: auto; object-fit: cover; border: 0px; vertical-align: text-top; opacity: 1; transition: opacity 400ms ease 0s;">

或是直接 [访问这里](https://github.com/messense/aliyundrive-webdav#%E8%8E%B7%E5%8F%96-refresh_token) 来获取 阿里云Token 的获取方法

### 设置网页访问入口

1、配置 主机名（软路由地址）、端口号

2、配置 阿里云盘 WebDAV 中的用户名，密码，并牢记

3、配置完成，保存并应用以后，在浏览器输入 [http://软路由地址](http://xn--ces6a908o44v3vb):端口号 ，输入刚才设置的用户名及密码，检查服务是否成功启动

## Rclone配置

### 配置 config 文件

SSH 连接软路由（或是在软路由的终端），输入以下代码配置 rclone。

1.  <span style="color: #e6e9ed;">rclone config</span>

具体配置过程大致如下（不排除软件以后更新，具体请自行翻译配置）

1.  <span style="color: #e6e9ed;">第一项：建立新项目</span> <span style="color: #e6e9ed;">\--</span> <span style="color: #e6e9ed;">n</span>
2.  <span style="color: #e6e9ed;">第二项：输入项目名字</span> <span style="color: #e6e9ed;">\--</span> <span style="color: #e6e9ed;">aliyun</span>
3.  <span style="color: #e6e9ed;">第三项：选择需要挂载的项目</span> <span style="color: #ac92ec;">46</span> <span style="color: #e6e9ed;">\--</span> <span style="color: #4fc1e9;">WebDAV</span>
4.  <span style="color: #e6e9ed;">第四项：输入</span><span style="color: #4fc1e9;">WebDAV</span><span style="color: #e6e9ed;">的挂载网址</span> <span style="color: #e6e9ed;">\--</span> <span style="color: #e6e9ed;">http</span><span style="color: #e6e9ed;">:</span><span style="color: #656d78;">[//10.0.0.3:8080](# "//10.0.0.3:8080")</span>
5.  <span style="color: #e6e9ed;">第五项：选择正在使用</span><span style="color: #4fc1e9;">WebDAV</span><span style="color: #e6e9ed;">的名字</span> <span style="color: #ac92ec;">5</span> <span style="color: #e6e9ed;">\--</span> <span style="color: #4fc1e9;">Other</span> <span style="color: #e6e9ed;">site</span><span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">service</span> <span style="color: #4fc1e9;">or</span> <span style="color: #e6e9ed;">software</span>
6.  <span style="color: #e6e9ed;">第六项：输入挂载</span><span style="color: #4fc1e9;">WebDAV</span><span style="color: #e6e9ed;">的用户名</span> <span style="color: #e6e9ed;">\--</span> <span style="color: #e6e9ed;">admin</span> <span style="color: #e6e9ed;">你创建</span><span style="color: #4fc1e9;">WebDAV</span><span style="color: #e6e9ed;">服务的用户名</span>
7.  <span style="color: #e6e9ed;">第七项：选择登录的用户名密码模式</span> <span style="color: #e6e9ed;">\--</span> <span style="color: #e6e9ed;">y</span> <span style="color: #e6e9ed;">使用自己的密码</span>
8.  <span style="color: #e6e9ed;">第八项：输入挂载</span><span style="color: #4fc1e9;">WebDAV</span><span style="color: #e6e9ed;">的密码</span> <span style="color: #e6e9ed;">\--</span> <span style="color: #e6e9ed;">admin</span><span style="color: #e6e9ed;">（不会显示）你创建</span><span style="color: #4fc1e9;">WebDAV</span><span style="color: #e6e9ed;">服务的密码</span>
9.  <span style="color: #e6e9ed;">第九项：再次确认密码</span> <span style="color: #e6e9ed;">\--</span> <span style="color: #e6e9ed;">admin</span><span style="color: #e6e9ed;">（不会显示）</span> <span style="color: #e6e9ed;">你创建</span><span style="color: #4fc1e9;">WebDAV</span><span style="color: #e6e9ed;">服务的密码</span>
10. <span style="color: #e6e9ed;">第十项：输入</span><span style="color: #e6e9ed;">token</span> <span style="color: #e6e9ed;">\--</span> <span style="color: #e6e9ed;">直接回车</span> <span style="color: #e6e9ed;">默认空</span>
11. <span style="color: #e6e9ed;">第十一项：进入高级设置</span> <span style="color: #e6e9ed;">\--</span> <span style="color: #e6e9ed;">直接回车</span> <span style="color: #e6e9ed;">默认不进入</span>
12. <span style="color: #e6e9ed;">第十二项：配置完成并确认</span> <span style="color: #e6e9ed;">\--</span> <span style="color: #e6e9ed;">直接回车</span> <span style="color: #e6e9ed;">默认确定</span>
13. <span style="color: #e6e9ed;">第十三项：重回配置菜单</span> <span style="color: #e6e9ed;">\--</span> <span style="color: #e6e9ed;">q</span> <span style="color: #e6e9ed;">退出配置</span>

这样，在 VPS 会生成 `/root/.config/rclone` 的 rclone 的配置文件

### OpenWRT 配置 Rclone 开机自启

在 OpenWRT 里面配置 rclone 自启，有很多坑，博主试过很多方法，唯独这一个不容易出错，所以把这个方法献给新手小伙伴们！

#### 软路由安装 procps

在 OpenWRT 上面，使用 `ps` 命令的时候，不允许带参数，这个问题可以通过下面的命令，安装 procps 文件，这样就可以正常的使用 `ps` 命令的参数。

1.  <span style="color: #e6e9ed;">opkg update</span> <span style="color: #e6e9ed;">&&</span> <span style="color: #e6e9ed;">opkg install procps</span><span style="color: #e6e9ed;">\-</span><span style="color: #e6e9ed;">ng</span><span style="color: #e6e9ed;">\-</span><span style="color: #e6e9ed;">ps</span>
2.  <span style="color: #e6e9ed;">reboot</span>

若是软路由不能通过命令安装，也是可以直接下载：[procps-ng_3.3.16-3_x86_64.ipk](https://v2rayssr.com/wp-content/uploads/2023/02/procps-ng_3.3.16-3_x86_64.ipk_.zip) 文件，到软路由进行安装并重启生效。

#### 创建 rcloned 文件

1.  <span style="color: #e6e9ed;">wget</span> <span style="color: #e6e9ed;">\-</span><span style="color: #e6e9ed;">N</span> <span style="color: #e6e9ed;">\-</span><span style="color: #e6e9ed;">P</span> <span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">etc</span><span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">init</span><span style="color: #e6e9ed;">.</span><span style="color: #e6e9ed;">d https</span><span style="color: #e6e9ed;">:</span><span style="color: #656d78;">[//raw.githubusercontent.com/V2RaySSR/tool_sh/main/rcloned](# "//raw.githubusercontent.com/V2RaySSR/tool_sh/main/rcloned")</span>
    
2.  <span style="color: #656d78;">\#### 以下是 rclone 的手动命令 可以自己尝试一下</span>
    
3.  <span style="color: #e6e9ed;">bash</span> <span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">etc</span><span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">init</span><span style="color: #e6e9ed;">.</span><span style="color: #e6e9ed;">d</span><span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">rcloned start</span>
    
4.  <span style="color: #e6e9ed;">bash</span> <span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">etc</span><span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">init</span><span style="color: #e6e9ed;">.</span><span style="color: #e6e9ed;">d</span><span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">rcloned stop</span>
    
5.  <span style="color: #e6e9ed;">bash</span> <span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">etc</span><span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">init</span><span style="color: #e6e9ed;">.</span><span style="color: #e6e9ed;">d</span><span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">rcloned restart</span>
    

根据 视频中，修改 `/etc/init.d/rcloned` 文件

#### 软路由设置 rclone 开机自启

直接输入以下命令（推荐）

1.  <span style="color: #e6e9ed;">sed</span> <span style="color: #e6e9ed;">\-</span><span style="color: #e6e9ed;">i</span> <span style="color: #ffce54;">'$i\\sleep 20 && bash /etc/init.d/rcloned start'</span> <span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">etc</span><span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">rc</span><span style="color: #e6e9ed;">.</span><span style="color: #4fc1e9;">local</span>

**或是**，软路由进入 系统 – 启动项 -本地启动脚本，在 `exit 0` 之前，插入如下命令：

1.  <span style="color: #e6e9ed;">bash</span> <span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">etc</span><span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">init</span><span style="color: #e6e9ed;">.</span><span style="color: #e6e9ed;">d</span><span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">rcloned start</span>

## Docker 设置

### Docker 存储空间设置

1、对 PVE 正使用的盘进行扩容，步骤较多，请 [观看视频](https://youtu.be/9AI4k2Xgkus)

## <img decoding="async" class="alignnone size-full wp-image-110932 lazy entered loaded jop-noMdConv" src="https://v2rayssr.com/wp-content/uploads/2023/02/12.png" alt="OpenWRT+Emby构建完美家庭私人影音库！软路由、OpenWRT开机Rclone自动挂载阿里云盘，Docker Emby 开心版、支持服务器硬解！" width="700" height="260" data-src="https://v2rayssr.com/wp-content/uploads/2023/02/12.png" data-ll-status="loaded" style="max-width: 100%; height: auto; object-fit: cover; border: 0px; vertical-align: text-top; opacity: 1; transition: opacity 400ms ease 0s;">

2、挂载其他数据盘，如 移动硬盘 或是 PVE 重新指派一个盘。步骤较多，请 [观看视频](https://youtu.be/9AI4k2Xgkus)

## <img loading="lazy" decoding="async" class="alignnone size-full wp-image-110933 lazy entered loaded jop-noMdConv" src="https://v2rayssr.com/wp-content/uploads/2023/02/231.png" alt="OpenWRT+Emby构建完美家庭私人影音库！软路由、OpenWRT开机Rclone自动挂载阿里云盘，Docker Emby 开心版、支持服务器硬解！" width="700" height="301" data-src="https://v2rayssr.com/wp-content/uploads/2023/02/231.png" data-ll-status="loaded" style="max-width: 100%; height: auto; object-fit: cover; border: 0px; vertical-align: text-top; opacity: 1; transition: opacity 400ms ease 0s;">

### 创建 Emby Docker 容器

Emby，大家都知道，需要 密钥 才可以解除一些限制。以下教程中的 Docker 镜像 为 Emby 开心版（破解版）。大家有能力的，还是希望能多多支持正版软件。博主已经支持！！

找到软路由 Docker，点击 容器，点击 添加，点击 解析CLI – 命令行，贴入以下命令：

相关的挂载命令，若是不明白的话，[请看视频](https://youtu.be/9AI4k2Xgkus)

1.  <span style="color: #e6e9ed;">docker run \\</span>
2.  ```
     <span style="color: rgb(230, 233, 237);">\--</span><span style="color: rgb(230, 233, 237);">name</span> <span style="color: rgb(79, 193, 233);">EmbyServer</span> <span style="color: rgb(230, 233, 237);">\\</span>
    ```
    
3.  ```
     <span style="color: rgb(230, 233, 237);">\--</span><span style="color: rgb(230, 233, 237);">net</span><span style="color: rgb(230, 233, 237);">\=</span><span style="color: rgb(230, 233, 237);">host  \\</span>
    ```
    
4.  ```
     <span style="color: rgb(230, 233, 237);">\-</span><span style="color: rgb(230, 233, 237);">v</span> <span style="color: rgb(230, 233, 237);">/</span><span style="color: rgb(230, 233, 237);">docker</span><span style="color: rgb(230, 233, 237);">/</span><span style="color: rgb(230, 233, 237);">emby</span><span style="color: rgb(230, 233, 237);">:/</span><span style="color: rgb(230, 233, 237);">config \\</span>
    ```
    
5.  ```
     <span style="color: rgb(230, 233, 237);">\-</span><span style="color: rgb(230, 233, 237);">v</span> <span style="color: rgb(230, 233, 237);">/</span><span style="color: rgb(230, 233, 237);">aliyun</span><span style="color: rgb(230, 233, 237);">:/</span><span style="color: rgb(230, 233, 237);">aliyun \\</span>
    ```
    
6.  ```
     <span style="color: rgb(230, 233, 237);">\-</span><span style="color: rgb(230, 233, 237);">e TZ</span><span style="color: rgb(230, 233, 237);">\=</span><span style="color: rgb(255, 206, 84);">"Asia/Shanghai"</span> <span style="color: rgb(230, 233, 237);">\\</span>
    ```
    
7.  ```
     <span style="color: rgb(230, 233, 237);">\--</span><span style="color: rgb(230, 233, 237);">device</span> <span style="color: rgb(230, 233, 237);">/</span><span style="color: rgb(230, 233, 237);">dev</span><span style="color: rgb(230, 233, 237);">/</span><span style="color: rgb(230, 233, 237);">dri</span><span style="color: rgb(230, 233, 237);">:</span><span style="color: rgb(255, 206, 84);">/dev/</span><span style="color: rgb(230, 233, 237);">dri \\</span>
    ```
    
8.  ```
     <span style="color: rgb(230, 233, 237);">\-</span><span style="color: rgb(230, 233, 237);">e UID</span><span style="color: rgb(230, 233, 237);">\=</span><span style="color: rgb(172, 146, 236);">0</span> <span style="color: rgb(230, 233, 237);">\\</span>
    ```
    
9.  ```
     <span style="color: rgb(230, 233, 237);">\-</span><span style="color: rgb(230, 233, 237);">e GID</span><span style="color: rgb(230, 233, 237);">\=</span><span style="color: rgb(172, 146, 236);">0</span> <span style="color: rgb(230, 233, 237);">\\</span>
    ```
    
10. ```
    <span style="color: rgb(230, 233, 237);">\-</span><span style="color: rgb(230, 233, 237);">e GIDLIST</span><span style="color: rgb(230, 233, 237);">\=</span><span style="color: rgb(172, 146, 236);">0</span> <span style="color: rgb(230, 233, 237);">\\</span>
    ```
    
11. ```
    <span style="color: rgb(230, 233, 237);">\--</span><span style="color: rgb(230, 233, 237);">restart always \\</span>
    ```
    
12. ```
    <span style="color: rgb(230, 233, 237);">\-</span><span style="color: rgb(230, 233, 237);">d lovechen</span><span style="color: rgb(230, 233, 237);">/</span><span style="color: rgb(230, 233, 237);">embyserver</span><span style="color: rgb(230, 233, 237);">:</span><span style="color: rgb(230, 233, 237);">latest</span>
    ```
    
13. <span style="color: #656d78;">##########################################################</span>
14. <span style="color: #e6e9ed;">下面为命令的注解：（不明白请看</span> <span style="color: #e6e9ed;">演示视频）</span>
15. <span style="color: #e6e9ed;">第七行</span> <span style="color: #e6e9ed;">是配置</span> <span style="color: #4fc1e9;">Emby</span> <span style="color: #e6e9ed;">的硬件解码，若没有核显，或是不需要，可以删除</span>
16. <span style="color: #e6e9ed;">若是需要配置正版，只需要把最后一行的</span> <span style="color: #e6e9ed;">lovechen</span> <span style="color: #e6e9ed;">改为</span> <span style="color: #e6e9ed;">emby</span> <span style="color: #e6e9ed;">即可配置</span> <span style="color: #4fc1e9;">Emby</span> <span style="color: #e6e9ed;">官方</span> <span style="color: #4fc1e9;">Docker</span> <span style="color: #e6e9ed;">源</span>
17. <span style="color: #e6e9ed;">若是软路由没有开启科学上网模式，那么需要在</span> <span style="color: #4fc1e9;">Docker</span> <span style="color: #e6e9ed;">环境参数里面加上</span>
18. <span style="color: #e6e9ed;">HTTP_PROXY</span><span style="color: #e6e9ed;">\=</span><span style="color: #e6e9ed;">http</span><span style="color: #e6e9ed;">:</span><span style="color: #656d78;">//代理IP:代理端口</span>
19. <span style="color: #e6e9ed;">HTTPS_PROXY</span><span style="color: #e6e9ed;">\=</span><span style="color: #e6e9ed;">http</span><span style="color: #e6e9ed;">:</span><span style="color: #656d78;">//代理IP:代理端口</span>
20. <span style="color: #e6e9ed;">（这样搜刮器才能正常的进行工作，因为大部分搜刮器已被墙）</span>
21. <span style="color: #656d78;">\# 第二行：设置 Docker 名字</span>
22. <span style="color: #656d78;">\# 第三行：设置网络模式</span>
23. <span style="color: #656d78;">\# 第四行：Emby 的配置路径</span>
24. <span style="color: #656d78;">\# 第五行：需要挂载的影视库路径</span>
25. <span style="color: #656d78;">\# 第六行：设置时区</span>
26. <span style="color: #656d78;">\# 第七行：配置核显解码（若软路由不支持核显，可删除）</span>
27. <span style="color: #656d78;">\# 第八行：设置权限</span>
28. <span style="color: #656d78;">\# 第九行：设置权限</span>
29. <span style="color: #656d78;">\# 第十行：设置权限</span>
30. <span style="color: #656d78;">\# 第十一行：设置权限</span>
31. <span style="color: #656d78;">\# 第十二行：Docker 版本</span>

配置完毕，点击提交，并启动容器

## 配置 Emby

### Emby 系统配置

浏览器输入 `http://软路由地址:8096` 进入 emby 的配置界面，详细的配置 [请看视频](https://youtu.be/9AI4k2Xgkus)

### 关闭服务器解码

当然，若你的服务器支持硬解，开启之后，客户端若无解码器，也是能够用服务器的硬解来舒缓服务器的压力。

若你的服务器不支持硬解，那么 **强烈推荐** 关闭服务器解码，不然看电影的时候，若是客户端没有解码器，那服务器绝对负载 100%，因为目前大家的软路由配置也并不是那么强大。

进入 Emby 后台，找到用户，在所有用户的配置界面，关闭如下配置选项：

## <img loading="lazy" decoding="async" class="alignnone size-full wp-image-110944 lazy entered loaded jop-noMdConv" src="https://v2rayssr.com/wp-content/uploads/2023/02/12331.png" alt="OpenWRT+Emby构建完美家庭私人影音库！软路由、OpenWRT开机Rclone自动挂载阿里云盘，Docker Emby 开心版、支持服务器硬解！" width="700" height="317" data-src="https://v2rayssr.com/wp-content/uploads/2023/02/12331.png" data-ll-status="loaded" style="max-width: 100%; height: auto; object-fit: cover; border: 0px; vertical-align: text-top; opacity: 1; transition: opacity 400ms ease 0s;">

### Emby 搜刮器配置

关于搜刮器，个人都有个人的喜好，本身来讲 Emby 已经支持中文，很多地方也都看得明白。但是我更为推荐 `themoviedb` 搜刮。

## 客户端配置

### 若你是正版的 Emby

那么 [官方的客户端](https://emby.media/download.html) ，就是你最好的选择，包含了 IOS/MACOS/WINDOWS/ANDROID/ANDROID TV 等平台的客户端。

### 若你是开心版 Emby

Windows PC、Android TV 推荐使用 KODI 作为客户端播放器。这样可以在客户机上面进行解码。

> 关于 KODI Emby 插件的安装，其实网上的教程也是很多的，若是大家实在是搞不明白，欢迎在视频下方留言。

MacOS 、IOS 推荐使用 INFUSE 软件作为客户端播放器。

Android 用户，推荐下载 [官方的客户端](https://emby.media/download.html)，使用更为的方便。

<span style="color: #ff0000;">**当然也是可以自行搜索 “[Android emby 客户端破解版](https://www.google.com/search?q=Android+emby+%E5%AE%A2%E6%88%B7%E7%AB%AF%E7%A0%B4%E8%A7%A3%E7%89%88&oq=Android+emby+%E5%AE%A2%E6%88%B7%E7%AB%AF%E7%A0%B4%E8%A7%A3%E7%89%88&aqs=chrome..69i57j33i160.422j0j7&sourceid=chrome&ie=UTF-8) 、 [Android TV emby 客户端破解版](https://www.google.com/search?q=Android+TV+emby+%E5%AE%A2%E6%88%B7%E7%AB%AF%E7%A0%B4%E8%A7%A3%E7%89%88&ei=R8b6Y5uLErD14-EPp42EmAw&ved=0ahUKEwjbyvWflLL9AhWw-jgGHacGAcMQ4dUDCA8&uact=5&oq=Android+TV+emby+%E5%AE%A2%E6%88%B7%E7%AB%AF%E7%A0%B4%E8%A7%A3%E7%89%88&gs_lcp=Cgxnd3Mtd2l6LXNlcnAQAzIFCAAQogQyBQgAEKIEMgUIABCiBDIFCAAQogRKBAhBGABQAFgAYMEDaABwAXgAgAG2AYgBtgGSAQMwLjGYAQCgAQKgAQHAAQE&sclient=gws-wiz-serp)”**</span>

## 后记

到这里，使用 OpenWRT 开机 Rclone 自动挂载 阿里云盘 的教程也就结束了，期间，我使用各种方法来测试搭建的可靠性（就是完全不出错），只有这一种最为简单，最为稳定，也最为被新手小伙伴们所接受！就到这里了。

## 准备工作

- 1、软路由（旁路由）一台，平台不限，本期视频以 X86 平台作为演示
- 2、阿里云账号一个（这个大家都有吧）

相关工具下载：

- 本期视频使用的软路由固件：[点击下载](https://v2rayssr.com/openwrt.html)

## 软路由阿里云盘设置

### 获取 Refresh Token

进入软路由的 服务 – 阿里云盘WebDAV ，启用并双击 Refresh Token ，登录手机 阿里云盘，扫描二维码，获取阿里云的登录 Token。

<img decoding="async" class="alignnone size-full wp-image-110938 lazy entered loaded jop-noMdConv" src="https://v2rayssr.com/wp-content/uploads/2023/02/1222.png" alt="OpenWRT+Emby构建完美家庭私人影音库！软路由、OpenWRT开机Rclone自动挂载阿里云盘，Docker Emby 开心版、支持服务器硬解！" width="700" height="664" data-src="https://v2rayssr.com/wp-content/uploads/2023/02/1222.png" data-ll-status="loaded" style="max-width: 100%; height: auto; object-fit: cover; border: 0px; vertical-align: text-top; opacity: 1; transition: opacity 400ms ease 0s;">

或是直接 [访问这里](https://github.com/messense/aliyundrive-webdav#%E8%8E%B7%E5%8F%96-refresh_token) 来获取 阿里云Token 的获取方法

### 设置网页访问入口

1、配置 主机名（软路由地址）、端口号

2、配置 阿里云盘 WebDAV 中的用户名，密码，并牢记

3、配置完成，保存并应用以后，在浏览器输入 [http://软路由地址](http://xn--ces6a908o44v3vb):端口号 ，输入刚才设置的用户名及密码，检查服务是否成功启动

## Rclone配置

### 配置 config 文件

SSH 连接软路由（或是在软路由的终端），输入以下代码配置 rclone。

1.  <span style="color: #e6e9ed;">rclone config</span>

具体配置过程大致如下（不排除软件以后更新，具体请自行翻译配置）

1.  <span style="color: #e6e9ed;">第一项：建立新项目</span> <span style="color: #e6e9ed;">\--</span> <span style="color: #e6e9ed;">n</span>
2.  <span style="color: #e6e9ed;">第二项：输入项目名字</span> <span style="color: #e6e9ed;">\--</span> <span style="color: #e6e9ed;">aliyun</span>
3.  <span style="color: #e6e9ed;">第三项：选择需要挂载的项目</span> <span style="color: #ac92ec;">46</span> <span style="color: #e6e9ed;">\--</span> <span style="color: #4fc1e9;">WebDAV</span>
4.  <span style="color: #e6e9ed;">第四项：输入</span><span style="color: #4fc1e9;">WebDAV</span><span style="color: #e6e9ed;">的挂载网址</span> <span style="color: #e6e9ed;">\--</span> <span style="color: #e6e9ed;">http</span><span style="color: #e6e9ed;">:</span><span style="color: #656d78;">[//10.0.0.3:8080](# "//10.0.0.3:8080")</span>
5.  <span style="color: #e6e9ed;">第五项：选择正在使用</span><span style="color: #4fc1e9;">WebDAV</span><span style="color: #e6e9ed;">的名字</span> <span style="color: #ac92ec;">5</span> <span style="color: #e6e9ed;">\--</span> <span style="color: #4fc1e9;">Other</span> <span style="color: #e6e9ed;">site</span><span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">service</span> <span style="color: #4fc1e9;">or</span> <span style="color: #e6e9ed;">software</span>
6.  <span style="color: #e6e9ed;">第六项：输入挂载</span><span style="color: #4fc1e9;">WebDAV</span><span style="color: #e6e9ed;">的用户名</span> <span style="color: #e6e9ed;">\--</span> <span style="color: #e6e9ed;">admin</span> <span style="color: #e6e9ed;">你创建</span><span style="color: #4fc1e9;">WebDAV</span><span style="color: #e6e9ed;">服务的用户名</span>
7.  <span style="color: #e6e9ed;">第七项：选择登录的用户名密码模式</span> <span style="color: #e6e9ed;">\--</span> <span style="color: #e6e9ed;">y</span> <span style="color: #e6e9ed;">使用自己的密码</span>
8.  <span style="color: #e6e9ed;">第八项：输入挂载</span><span style="color: #4fc1e9;">WebDAV</span><span style="color: #e6e9ed;">的密码</span> <span style="color: #e6e9ed;">\--</span> <span style="color: #e6e9ed;">admin</span><span style="color: #e6e9ed;">（不会显示）你创建</span><span style="color: #4fc1e9;">WebDAV</span><span style="color: #e6e9ed;">服务的密码</span>
9.  <span style="color: #e6e9ed;">第九项：再次确认密码</span> <span style="color: #e6e9ed;">\--</span> <span style="color: #e6e9ed;">admin</span><span style="color: #e6e9ed;">（不会显示）</span> <span style="color: #e6e9ed;">你创建</span><span style="color: #4fc1e9;">WebDAV</span><span style="color: #e6e9ed;">服务的密码</span>
10. <span style="color: #e6e9ed;">第十项：输入</span><span style="color: #e6e9ed;">token</span> <span style="color: #e6e9ed;">\--</span> <span style="color: #e6e9ed;">直接回车</span> <span style="color: #e6e9ed;">默认空</span>
11. <span style="color: #e6e9ed;">第十一项：进入高级设置</span> <span style="color: #e6e9ed;">\--</span> <span style="color: #e6e9ed;">直接回车</span> <span style="color: #e6e9ed;">默认不进入</span>
12. <span style="color: #e6e9ed;">第十二项：配置完成并确认</span> <span style="color: #e6e9ed;">\--</span> <span style="color: #e6e9ed;">直接回车</span> <span style="color: #e6e9ed;">默认确定</span>
13. <span style="color: #e6e9ed;">第十三项：重回配置菜单</span> <span style="color: #e6e9ed;">\--</span> <span style="color: #e6e9ed;">q</span> <span style="color: #e6e9ed;">退出配置</span>

这样，在 VPS 会生成 `/root/.config/rclone` 的 rclone 的配置文件

### OpenWRT 配置 Rclone 开机自启

在 OpenWRT 里面配置 rclone 自启，有很多坑，博主试过很多方法，唯独这一个不容易出错，所以把这个方法献给新手小伙伴们！

#### 软路由安装 procps

在 OpenWRT 上面，使用 `ps` 命令的时候，不允许带参数，这个问题可以通过下面的命令，安装 procps 文件，这样就可以正常的使用 `ps` 命令的参数。

1.  <span style="color: #e6e9ed;">opkg update</span> <span style="color: #e6e9ed;">&&</span> <span style="color: #e6e9ed;">opkg install procps</span><span style="color: #e6e9ed;">\-</span><span style="color: #e6e9ed;">ng</span><span style="color: #e6e9ed;">\-</span><span style="color: #e6e9ed;">ps</span>
2.  <span style="color: #e6e9ed;">reboot</span>

若是软路由不能通过命令安装，也是可以直接下载：[procps-ng_3.3.16-3_x86_64.ipk](https://v2rayssr.com/wp-content/uploads/2023/02/procps-ng_3.3.16-3_x86_64.ipk_.zip) 文件，到软路由进行安装并重启生效。

#### 创建 rcloned 文件

1.  <span style="color: #e6e9ed;">wget</span> <span style="color: #e6e9ed;">\-</span><span style="color: #e6e9ed;">N</span> <span style="color: #e6e9ed;">\-</span><span style="color: #e6e9ed;">P</span> <span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">etc</span><span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">init</span><span style="color: #e6e9ed;">.</span><span style="color: #e6e9ed;">d https</span><span style="color: #e6e9ed;">:</span><span style="color: #656d78;">[//raw.githubusercontent.com/V2RaySSR/tool_sh/main/rcloned](# "//raw.githubusercontent.com/V2RaySSR/tool_sh/main/rcloned")</span>
    
2.  <span style="color: #656d78;">\#### 以下是 rclone 的手动命令 可以自己尝试一下</span>
    
3.  <span style="color: #e6e9ed;">bash</span> <span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">etc</span><span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">init</span><span style="color: #e6e9ed;">.</span><span style="color: #e6e9ed;">d</span><span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">rcloned start</span>
    
4.  <span style="color: #e6e9ed;">bash</span> <span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">etc</span><span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">init</span><span style="color: #e6e9ed;">.</span><span style="color: #e6e9ed;">d</span><span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">rcloned stop</span>
    
5.  <span style="color: #e6e9ed;">bash</span> <span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">etc</span><span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">init</span><span style="color: #e6e9ed;">.</span><span style="color: #e6e9ed;">d</span><span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">rcloned restart</span>
    

根据 视频中，修改 `/etc/init.d/rcloned` 文件

#### 软路由设置 rclone 开机自启

直接输入以下命令（推荐）

1.  <span style="color: #e6e9ed;">sed</span> <span style="color: #e6e9ed;">\-</span><span style="color: #e6e9ed;">i</span> <span style="color: #ffce54;">'$i\\sleep 20 && bash /etc/init.d/rcloned start'</span> <span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">etc</span><span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">rc</span><span style="color: #e6e9ed;">.</span><span style="color: #4fc1e9;">local</span>

**或是**，软路由进入 系统 – 启动项 -本地启动脚本，在 `exit 0` 之前，插入如下命令：

1.  <span style="color: #e6e9ed;">bash</span> <span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">etc</span><span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">init</span><span style="color: #e6e9ed;">.</span><span style="color: #e6e9ed;">d</span><span style="color: #e6e9ed;">/</span><span style="color: #e6e9ed;">rcloned start</span>

## Docker 设置

### Docker 存储空间设置

1、对 PVE 正使用的盘进行扩容，步骤较多，请 [观看视频](https://youtu.be/9AI4k2Xgkus)

<img decoding="async" class="alignnone size-full wp-image-110932 lazy entered loaded jop-noMdConv" src="https://v2rayssr.com/wp-content/uploads/2023/02/12.png" alt="OpenWRT+Emby构建完美家庭私人影音库！软路由、OpenWRT开机Rclone自动挂载阿里云盘，Docker Emby 开心版、支持服务器硬解！" width="700" height="260" data-src="https://v2rayssr.com/wp-content/uploads/2023/02/12.png" data-ll-status="loaded" style="max-width: 100%; height: auto; object-fit: cover; border: 0px; vertical-align: text-top; opacity: 1; transition: opacity 400ms ease 0s;">

2、挂载其他数据盘，如 移动硬盘 或是 PVE 重新指派一个盘。步骤较多，请 [观看视频](https://youtu.be/9AI4k2Xgkus)

<img loading="lazy" decoding="async" class="alignnone size-full wp-image-110933 lazy entered loaded jop-noMdConv" src="https://v2rayssr.com/wp-content/uploads/2023/02/231.png" alt="OpenWRT+Emby构建完美家庭私人影音库！软路由、OpenWRT开机Rclone自动挂载阿里云盘，Docker Emby 开心版、支持服务器硬解！" width="700" height="301" data-src="https://v2rayssr.com/wp-content/uploads/2023/02/231.png" data-ll-status="loaded" style="max-width: 100%; height: auto; object-fit: cover; border: 0px; vertical-align: text-top; opacity: 1; transition: opacity 400ms ease 0s;">

### 创建 Emby Docker 容器

Emby，大家都知道，需要 密钥 才可以解除一些限制。以下教程中的 Docker 镜像 为 Emby 开心版（破解版）。大家有能力的，还是希望能多多支持正版软件。博主已经支持！！

找到软路由 Docker，点击 容器，点击 添加，点击 解析CLI – 命令行，贴入以下命令：

相关的挂载命令，若是不明白的话，[请看视频](https://youtu.be/9AI4k2Xgkus)

1.  <span style="color: #e6e9ed;">docker run \\</span>
    
2.  ```
     <span style="color: rgb(230, 233, 237);">\--</span><span style="color: rgb(230, 233, 237);">name</span> <span style="color: rgb(79, 193, 233);">EmbyServer</span> <span style="color: rgb(230, 233, 237);">\\</span>
    ```
    
3.  ```
     <span style="color: rgb(230, 233, 237);">\--</span><span style="color: rgb(230, 233, 237);">net</span><span style="color: rgb(230, 233, 237);">\=</span><span style="color: rgb(230, 233, 237);">host  \\</span>
    ```
    
4.  ```
     <span style="color: rgb(230, 233, 237);">\-</span><span style="color: rgb(230, 233, 237);">v</span> <span style="color: rgb(230, 233, 237);">/</span><span style="color: rgb(230, 233, 237);">docker</span><span style="color: rgb(230, 233, 237);">/</span><span style="color: rgb(230, 233, 237);">emby</span><span style="color: rgb(230, 233, 237);">:/</span><span style="color: rgb(230, 233, 237);">config \\</span>
    ```
    
5.  ```
     <span style="color: rgb(230, 233, 237);">\-</span><span style="color: rgb(230, 233, 237);">v</span> <span style="color: rgb(230, 233, 237);">/</span><span style="color: rgb(230, 233, 237);">aliyun</span><span style="color: rgb(230, 233, 237);">:/</span><span style="color: rgb(230, 233, 237);">aliyun \\</span>
    ```
    
6.  ```
     <span style="color: rgb(230, 233, 237);">\-</span><span style="color: rgb(230, 233, 237);">e TZ</span><span style="color: rgb(230, 233, 237);">\=</span><span style="color: rgb(255, 206, 84);">"Asia/Shanghai"</span> <span style="color: rgb(230, 233, 237);">\\</span>
    ```
    
7.  ```
     <span style="color: rgb(230, 233, 237);">\--</span><span style="color: rgb(230, 233, 237);">device</span> <span style="color: rgb(230, 233, 237);">/</span><span style="color: rgb(230, 233, 237);">dev</span><span style="color: rgb(230, 233, 237);">/</span><span style="color: rgb(230, 233, 237);">dri</span><span style="color: rgb(230, 233, 237);">:</span><span style="color: rgb(255, 206, 84);">/dev/</span><span style="color: rgb(230, 233, 237);">dri \\</span>
    ```
    
8.  ```
     <span style="color: rgb(230, 233, 237);">\-</span><span style="color: rgb(230, 233, 237);">e UID</span><span style="color: rgb(230, 233, 237);">\=</span><span style="color: rgb(172, 146, 236);">0</span> <span style="color: rgb(230, 233, 237);">\\</span>
    ```
    
9.  ```
     <span style="color: rgb(230, 233, 237);">\-</span><span style="color: rgb(230, 233, 237);">e GID</span><span style="color: rgb(230, 233, 237);">\=</span><span style="color: rgb(172, 146, 236);">0</span> <span style="color: rgb(230, 233, 237);">\\</span>
    ```
    
10. ```
    <span style="color: rgb(230, 233, 237);">\-</span><span style="color: rgb(230, 233, 237);">e GIDLIST</span><span style="color: rgb(230, 233, 237);">\=</span><span style="color: rgb(172, 146, 236);">0</span> <span style="color: rgb(230, 233, 237);">\\</span>
    ```
    
11. ```
    <span style="color: rgb(230, 233, 237);">\--</span><span style="color: rgb(230, 233, 237);">restart always \\</span>
    ```
    
12. ```
    <span style="color: rgb(230, 233, 237);">\-</span><span style="color: rgb(230, 233, 237);">d lovechen</span><span style="color: rgb(230, 233, 237);">/</span><span style="color: rgb(230, 233, 237);">embyserver</span><span style="color: rgb(230, 233, 237);">:</span><span style="color: rgb(230, 233, 237);">latest</span>
    ```
    
13. <span style="color: #656d78;">##########################################################</span>
    
14. <span style="color: #e6e9ed;">下面为命令的注解：（不明白请看</span> <span style="color: #e6e9ed;">演示视频）</span>
    
15. <span style="color: #e6e9ed;">第七行</span> <span style="color: #e6e9ed;">是配置</span> <span style="color: #4fc1e9;">Emby</span> <span style="color: #e6e9ed;">的硬件解码，若没有核显，或是不需要，可以删除</span>
    
16. <span style="color: #e6e9ed;">若是需要配置正版，只需要把最后一行的</span> <span style="color: #e6e9ed;">lovechen</span> <span style="color: #e6e9ed;">改为</span> <span style="color: #e6e9ed;">emby</span> <span style="color: #e6e9ed;">即可配置</span> <span style="color: #4fc1e9;">Emby</span> <span style="color: #e6e9ed;">官方</span> <span style="color: #4fc1e9;">Docker</span> <span style="color: #e6e9ed;">源</span>
    
17. <span style="color: #e6e9ed;">若是软路由没有开启科学上网模式，那么需要在</span> <span style="color: #4fc1e9;">Docker</span> <span style="color: #e6e9ed;">环境参数里面加上</span>
    
18. <span style="color: #e6e9ed;">HTTP_PROXY</span><span style="color: #e6e9ed;">\=</span><span style="color: #e6e9ed;">http</span><span style="color: #e6e9ed;">:</span><span style="color: #656d78;">//代理IP:代理端口</span>
    
19. <span style="color: #e6e9ed;">HTTPS_PROXY</span><span style="color: #e6e9ed;">\=</span><span style="color: #e6e9ed;">http</span><span style="color: #e6e9ed;">:</span><span style="color: #656d78;">//代理IP:代理端口</span>
    
20. <span style="color: #e6e9ed;">（这样搜刮器才能正常的进行工作，因为大部分搜刮器已被墙）</span>
    
21. <span style="color: #656d78;">\# 第二行：设置 Docker 名字</span>
    
22. <span style="color: #656d78;">\# 第三行：设置网络模式</span>
    
23. <span style="color: #656d78;">\# 第四行：Emby 的配置路径</span>
    
24. <span style="color: #656d78;">\# 第五行：需要挂载的影视库路径</span>
    
25. <span style="color: #656d78;">\# 第六行：设置时区</span>
    
26. <span style="color: #656d78;">\# 第七行：配置核显解码（若软路由不支持核显，可删除）</span>
    
27. <span style="color: #656d78;">\# 第八行：设置权限</span>
    
28. <span style="color: #656d78;">\# 第九行：设置权限</span>
    
29. <span style="color: #656d78;">\# 第十行：设置权限</span>
    
30. <span style="color: #656d78;">\# 第十一行：设置权限</span>
    
31. <span style="color: #656d78;">\# 第十二行：Docker 版本</span>
    

配置完毕，点击提交，并启动容器

## 配置 Emby

### Emby 系统配置

浏览器输入 `http://软路由地址:8096` 进入 emby 的配置界面，详细的配置 [请看视频](https://youtu.be/9AI4k2Xgkus)

### 关闭服务器解码

当然，若你的服务器支持硬解，开启之后，客户端若无解码器，也是能够用服务器的硬解来舒缓服务器的压力。

若你的服务器不支持硬解，那么 **强烈推荐** 关闭服务器解码，不然看电影的时候，若是客户端没有解码器，那服务器绝对负载 100%，因为目前大家的软路由配置也并不是那么强大。

进入 Emby 后台，找到用户，在所有用户的配置界面，关闭如下配置选项：

<img loading="lazy" decoding="async" class="alignnone size-full wp-image-110944 lazy entered loaded jop-noMdConv" src="https://v2rayssr.com/wp-content/uploads/2023/02/12331.png" alt="OpenWRT+Emby构建完美家庭私人影音库！软路由、OpenWRT开机Rclone自动挂载阿里云盘，Docker Emby 开心版、支持服务器硬解！" width="700" height="317" data-src="https://v2rayssr.com/wp-content/uploads/2023/02/12331.png" data-ll-status="loaded" style="max-width: 100%; height: auto; object-fit: cover; border: 0px; vertical-align: text-top; opacity: 1; transition: opacity 400ms ease 0s;">

### Emby 搜刮器配置

关于搜刮器，个人都有个人的喜好，本身来讲 Emby 已经支持中文，很多地方也都看得明白。但是我更为推荐 `themoviedb` 搜刮。

## 客户端配置

### 若你是正版的 Emby

那么 [官方的客户端](https://emby.media/download.html) ，就是你最好的选择，包含了 IOS/MACOS/WINDOWS/ANDROID/ANDROID TV 等平台的客户端。

### 若你是开心版 Emby

Windows PC、Android TV 推荐使用 KODI 作为客户端播放器。这样可以在客户机上面进行解码。

> 关于 KODI Emby 插件的安装，其实网上的教程也是很多的，若是大家实在是搞不明白，欢迎在视频下方留言。

MacOS 、IOS 推荐使用 INFUSE 软件作为客户端播放器。

Android 用户，推荐下载 [官方的客户端](https://emby.media/download.html)，使用更为的方便。

<span style="color: #ff0000;">**当然也是可以自行搜索 “[Android emby 客户端破解版](https://www.google.com/search?q=Android+emby+%E5%AE%A2%E6%88%B7%E7%AB%AF%E7%A0%B4%E8%A7%A3%E7%89%88&oq=Android+emby+%E5%AE%A2%E6%88%B7%E7%AB%AF%E7%A0%B4%E8%A7%A3%E7%89%88&aqs=chrome..69i57j33i160.422j0j7&sourceid=chrome&ie=UTF-8) 、 [Android TV emby 客户端破解版](https://www.google.com/search?q=Android+TV+emby+%E5%AE%A2%E6%88%B7%E7%AB%AF%E7%A0%B4%E8%A7%A3%E7%89%88&ei=R8b6Y5uLErD14-EPp42EmAw&ved=0ahUKEwjbyvWflLL9AhWw-jgGHacGAcMQ4dUDCA8&uact=5&oq=Android+TV+emby+%E5%AE%A2%E6%88%B7%E7%AB%AF%E7%A0%B4%E8%A7%A3%E7%89%88&gs_lcp=Cgxnd3Mtd2l6LXNlcnAQAzIFCAAQogQyBQgAEKIEMgUIABCiBDIFCAAQogRKBAhBGABQAFgAYMEDaABwAXgAgAG2AYgBtgGSAQMwLjGYAQCgAQKgAQHAAQE&sclient=gws-wiz-serp)”**</span>

## 后记

到这里，使用 OpenWRT 开机 Rclone 自动挂载 阿里云盘 的教程也就结束了，期间，我使用各种方法来测试搭建的可靠性（就是完全不出错），只有这一种最为简单，最为稳定，也最为被新手小伙伴们所接受！就到这里了。