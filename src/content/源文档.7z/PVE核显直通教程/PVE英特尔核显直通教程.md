# PVE英特尔核显直通教程

> [!WARNING]
>
> 这里是PVE8以上才采用这个方案，演示的版本是PVE8.2.4，不建议高版本尝试本方案。

## 第一步：启用IOMMU

### 修改 `/etc/default/grub`

```bash
vi /etc/default/grub
```

找到其中的`GRUB_CMDLINE_LINUX_DEFAULT`部分，修改双引号后的参数，**注意双引号要为英文双引号！**

```shell
GRUB_DEFAULT=0
GRUB_TIMEOUT=5
GRUB_CMDLINE_LINUX_DEFAULT="quiet intel_iommu=on"   <<< 这里增加intel_iommu=on的参数
GRUB_CMDLINE_LINXU=""
```

## 第二步：编辑/etc/modprobe.d/pve-blacklist.conf

```bash
vi /etc/modprobe.d/pve-blacklist.conf
```

内部可能会留有一些屏蔽i915和nvidia的配置项目，直接注释并且填入如下内容

```bash
blacklist nvidiafb
blacklist amdgpu
blacklist i915
blacklist snd_hda_intel
options vfio_iommu_type allow_unsafe_interrupts=1
```

## 第三步：编译内核、GRUB配置文件

```shell
update-initramfs -u -k all && update-grub
```

## 第四部：下载rom文件

> [!IMPORTANT]
>
> 这里有两个不同作者的ROM文件，如果采用一个方案后出现了花屏，死机等情况，请更换别的作者的rom文件！

### 方案一：ganqizai大佬

[项目地址-Github源地址](https://github.com/gangqizai/igd) 🌸 [直接下载整个项目-镜像加速](https://ghfast.top/https://github.com/gangqizai/igd/archive/refs/heads/main.zip)

#### 项目摘要

- 本ROM为Intel 10-13核显直通PCI optionROM, 搭配OVMF可以实现虚拟机启动,显示器 HDMI/DP 输出画面, HDMI/DP声音正常工作

- 本ROM使用简单,无需修改或定制OVMF,使用PVE自带即可!

- 虚拟机启动无花屏，蓝屏。

  ### 使用方法:

  - 本ROM 需要使用两个rom文件:
    - 核显直通 OptionROM: **gen12_igd.rom** --各平台基本通用
    - GOP ROM: --- 根据不同核显平台选择相应rom文件，见下表：

  | GOP ROM 文件名 | 适用CPU平台        |
  | -------------- | ------------------ |
  | gen12_gop.rom  | Intel 11-13代 酷睿 |
  | 5105_gop.rom   | N5105 / N5095      |
  | 8505_gop.rom   | 8505               |

  - 大家根据主机的CPU选用相应GOP ROM，选用错误GOP ROM功能导致无启动画面

  - 把这两个rom file copy to /use/share/kvm/

  - 因为使用两个rom文件，conf配置文件中，一个rom文件加在显卡，另一个加在声卡,大家注意一下。

    ```
    hostpci0: 0000:00:02.0,legacy-igd=1,romfile=gen12_igd.rom
    hostpci1: 0000:00:1f.3,romfile=gen12_gop.rom
    ```

### 方案二：李晓流大佬

[项目地址Github原地址](https://github.com/lixiaoliu666/intel6-14rom) 🌸 由于大佬更新速度很快，请直接在原地址的[Release](https://github.com/lixiaoliu666/intel6-14rom/releases/)处下载



## 第五步：添加核显和声卡的PCI直通

**确保设置显示部分为无**

![PVE-1](F:\MareDocument\源文档\PVE\PVE-1.png)

**并且添加进核显和声卡**，一般核显地址固定为`0000:00:02.0` 声卡为`0000:00:1f.3` 直接添加即可 

<img src="F:\MareDocument\源文档\PVE\PVE-2.png" alt="PVE-2" style="zoom: 80%;" />

## 第六步：编辑虚拟机的配置文件增加参数

###  打开你的虚拟机配置文件

 ```shell
 vi /etc/pve/qemu-server/100.conf   <<< 注意这里的100要替换为你的虚拟机ID
 ```

在整个文件的开头添加如下参数

```shell
args: -set device.hostpci0.addr=02.0 -set device.hostpci0.x-igd-gms=0x2 -set device.hostpci0.x-igd-opregion=on
```

显卡和声卡位置修改为如下

```shell
hostpci0: 0000:00:02.0,legacy-igd=1,romfile=<这里是你的rom文件名>.rom
hostpci1: 0000:00:1f.3,romfile=<这里也是你的rom文件名>.rom
```

![image-20250130182135844](F:\MareDocument\源文档\PVE\pve-3.png)

## 第七部：确保无误！保存开机！

确保你填写的文件无误，就可以保存开机了，如果你再直通显卡之前没有安装驱动，可能需要在系统内装上驱动或等待Windows自己安装好驱动就可以点亮。