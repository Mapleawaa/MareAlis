# 把local-lvm的空间全部分配给local

## 1.打开自带的shell窗口，输入后以下内容后回车  
```shell
lvremove pve/data
```

## 2.继续输入，然后回车

```shell
lvextend -l +100%FREE -r pve/root
```

## 3.在数据中心-存储中删除local-lvm分区，并编辑local，在内容一项中勾选所有可选项。